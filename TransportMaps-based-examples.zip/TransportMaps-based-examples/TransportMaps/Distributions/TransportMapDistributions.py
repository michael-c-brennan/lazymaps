#
# This file is part of TransportMaps.
#
# TransportMaps is free software: you can redistribute it and/or modify
# it under the terms of the GNU Lesser General Public License as published by
# the Free Software Foundation, either version 3 of the License, or
# (at your option) any later version.
#
# TransportMaps is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU Lesser General Public License for more details.
#
# You should have received a copy of the GNU Lesser General Public License
# along with TransportMaps.  If not, see <http://www.gnu.org/licenses/>.
#
# Transport Maps Library
# Copyright (C) 2015-2018 Massachusetts Institute of Technology
# Uncertainty Quantification group
# Department of Aeronautics and Astronautics
#
# Authors: Transport Map Team
# Website: transportmaps.mit.edu
# Support: transportmaps.mit.edu/qa/
#

import warnings
import numpy as np

from TransportMaps.Misc import mpi_map, counted, cached, cached_tuple
from TransportMaps.Maps import \
    CompositeMap,\
    InverseTransportMap
from .TransportMapDistributionBase import TransportMapDistribution

__all__ = [
    'PushForwardTransportMapDistribution',
    'PullBackTransportMapDistribution'
]

class PushForwardTransportMapDistribution(TransportMapDistribution):
    r""" Class for densities of the transport map type :math:`T_\sharp \pi`

    Args:
      transport_map (Maps.TriangularTransportMap): transport map :math:`T`
      base_distribution (Distributions.Distribution): distribution :math:`\pi`

    .. seealso:: :class:`TransportMapDistribution`
    """

    @counted
    def pdf(self, x, params=None, idxs_slice=slice(None), cache=None):
        r""" Evaluate :math:`T_\sharp \pi({\bf x})`

        Args:
          x (:class:`ndarray<numpy.ndarray>` [:math:`m,d`]): evaluation points
          params (dict): parameters with keys ``params_pi``, ``params_t``
          idxs_slice (slice): if precomputed values are present, this parameter
            indicates at which of the points to evaluate. The number of indices
            represented by ``idxs_slice`` must match ``x.shape[0]``.
          cache (dict): cache

        Returns:
          (:class:`ndarray<numpy.ndarray>` [:math:`m`]) -- values of :math:`T_\sharp \pi`
            at the ``x`` points.
        """
        return np.exp( self.log_pdf(x, params, idxs_slice=idxs_slice, cache=cache) )

    @cached()
    @counted
    def log_pdf(self, x, params=None, idxs_slice=slice(None), cache=None):
        r""" Evaluate :math:`\log T_\sharp \pi({\bf x})`

        Args:
          x (:class:`ndarray<numpy.ndarray>` [:math:`m,d`]): evaluation points
          params (dict): parameters with keys ``params_pi``, ``params_t``
          idxs_slice (slice): if precomputed values are present, this parameter
            indicates at which of the points to evaluate. The number of indices
            represented by ``idxs_slice`` must match ``x.shape[0]``.
          cache (dict): cache

        Returns:
          (:class:`ndarray<numpy.ndarray>` [:math:`m`]) -- values of :math:`\log T_\sharp\pi`
            at the ``x`` points.
        """
        try:
            params_pi = params['params_pi']
        except (KeyError,TypeError):
            params_pi = None
        try:
            params_t = params['params_t']
        except (KeyError,TypeError):
            # idxs_slice = slice(None)
            params_t = None
        return self.transport_map.log_pushforward(
            x, self.base_distribution, params_t, params_pi, idxs_slice=idxs_slice,
            cache=cache)

    @cached()
    @counted
    def grad_x_log_pdf(
            self, x, params=None, idxs_slice=slice(None), cache=None, *args, **kwargs):
        r""" Evaluate :math:`\nabla_{\bf x} \log \pi({\bf x})`

        Args:
          x (:class:`ndarray<numpy.ndarray>` [:math:`m,d`]): evaluation points
          params (dict): parameters with keys ``params_pi``, ``params_t``
          idxs_slice (slice): if precomputed values are present, this parameter
            indicates at which of the points to evaluate. The number of indices
            represented by ``idxs_slice`` must match ``x.shape[0]``.

        Returns:
          (:class:`ndarray<numpy.ndarray>` [:math:`m,d`]) -- values of
            :math:`\nabla_x\log\pi` at the ``x`` points.
        """
        try:
            params_pi = params['params_pi']
        except (KeyError,TypeError):
            params_pi = None
        try:
            params_t = params['params_t']
        except (KeyError,TypeError):
            # idxs_slice = slice(None)
            params_t = None
        return self.transport_map.grad_x_log_pushforward(
            x, self.base_distribution, params_t=params_t, params_pi=params_pi,
            idxs_slice=idxs_slice, cache=cache)

    @cached_tuple(['log_pdf','grad_x_log_pdf'])
    @counted
    def tuple_grad_x_log_pdf(
            self, x, params=None, idxs_slice=slice(None), cache=None, *args, **kwargs):
        r""" Evaluate :math:`\left(\log \pi({\bf x}), \nabla_{\bf x} \log \pi({\bf x})\right)`

        Args:
          x (:class:`ndarray<numpy.ndarray>` [:math:`m,d`]): evaluation points
          params (dict): parameters with keys ``params_pi``, ``params_t``
          idxs_slice (slice): if precomputed values are present, this parameter
            indicates at which of the points to evaluate. The number of indices
            represented by ``idxs_slice`` must match ``x.shape[0]``.

        Returns:
          (:class:`tuple`) --
            :math:`\left(\log \pi({\bf x}), \nabla_{\bf x} \log \pi({\bf x})\right)`
        """
        try:
            params_pi = params['params_pi']
        except (KeyError,TypeError):
            params_pi = None
        try:
            params_t = params['params_t']
        except (KeyError,TypeError):
            # idxs_slice = slice(None)
            params_t = None
        return self.transport_map.tuple_grad_x_log_pushforward(
            x, self.base_distribution,
            params_t, params_pi, idxs_slice=idxs_slice, cache=cache)

    @cached(caching=False)
    @counted
    def hess_x_log_pdf(
            self, x, params=None, idxs_slice=slice(None), cache=None, *args, **kwargs):
        r""" Evaluate :math:`\nabla^2_{\bf x} \log \pi({\bf x})`

        Args:
          x (:class:`ndarray<numpy.ndarray>` [:math:`m,d`]): evaluation points
          params (dict): parameters with keys ``params_pi``, ``params_t``
          idxs_slice (slice): if precomputed values are present, this parameter
            indicates at which of the points to evaluate. The number of indices
            represented by ``idxs_slice`` must match ``x.shape[0]``.

        Returns:
          (:class:`ndarray<numpy.ndarray>` [:math:`m,d,d`]) -- values of
            :math:`\nabla^2_x\log\pi` at the ``x`` points.
        """
        try:
            params_pi = params['params_pi']
        except (KeyError,TypeError):
            params_pi = None
        try:
            params_t = params['params_t']
        except (KeyError,TypeError):
            # idxs_slice = slice(None)
            params_t = None
        return self.transport_map.hess_x_log_pushforward(
            x, self.base_distribution, params_t, params_pi,
            idxs_slice=idxs_slice, cache=cache)

    @cached(caching=False)
    @counted
    def action_hess_x_log_pdf(
            self, x, dx, params=None, idxs_slice=slice(None,None,None),
            cache=None, *args, **kwargs):
        r""" Evaluate :math:`\langle \nabla^2_{\bf x} \log \pi({\bf x}), \delta{\bf x}\rangle`

        Args:
          x (:class:`ndarray<numpy.ndarray>` [:math:`m,d`]): evaluation points
          dx (:class:`ndarray<numpy.ndarray>` [:math:`m,d`]): direction
            on which to evaluate the Hessian
          params (dict): parameters
          idxs_slice (slice): if precomputed values are present, this parameter
            indicates at which of the points to evaluate. The number of indices
            represented by ``idxs_slice`` must match ``x.shape[0]``.

        Returns:
          (:class:`ndarray<numpy.ndarray>` [:math:`m,d`]) -- values of
            :math:`\langle \nabla^2_{\bf x} \log \pi({\bf x}), \delta{\bf x}\rangle`.
        """
        try:
            params_pi = params['params_pi']
        except (KeyError,TypeError):
            params_pi = None
        try:
            params_t = params['params_t']
        except (KeyError,TypeError):
            # idxs_slice = slice(None)
            params_t = None
        return self.transport_map.action_hess_x_log_pushforward(
            x, self.base_distribution, dx,
            params_t, params_pi, idxs_slice=idxs_slice, cache=cache)

    def map_function_base_to_target(self, f):
        r""" Given the map :math:`f` returns :math:`f\circ T`

        Args:
          f (:class:`TransportMaps.Maps.Map<Map>`): the map :math:`f`

        Returns:
          (:class:`TransportMaps.Maps.CompositeMap<CompositeMap>`) -- :math:`f \circ T`
        """
        return CompositeMap(f, self.transport_map)
        
    def map_samples_base_to_target(self, x, mpi_pool=None):
        r""" Map input samples (assumed to be from :math:`\pi`) to the corresponding samples from :math:`T_\sharp \pi`.

        Args:
          x (:class:`ndarray<numpy.ndarray>` [:math:`m,d`]): input samples
          mpi_pool (:class:`mpi_map.MPI_Pool<mpi_map.MPI_Pool>`): pool of processes

        Returns:
          (:class:`ndarray<numpy.ndarray>` [:math:`m,d`]) -- corresponding samples
        """
        scatter_tuple = (['x'], [x])
        out = mpi_map("evaluate", scatter_tuple=scatter_tuple, obj=self.transport_map,
                       mpi_pool=mpi_pool)
        return out

    def map_samples_target_to_base(self, x, mpi_pool=None):
        r""" Map input samples assumed to be from :math:`T_\sharp \pi` to the corresponding samples from :math:`\pi`.

        Args:
          x (:class:`ndarray<numpy.ndarray>` [:math:`m,d`]): input samples
          mpi_pool (:class:`mpi_map.MPI_Pool<mpi_map.MPI_Pool>`): pool of processes

        Returns:
          (:class:`ndarray<numpy.ndarray>` [:math:`m,d`]) -- corresponding samples
        """
        scatter_tuple = (['x'], [x])
        out = mpi_map("inverse", scatter_tuple=scatter_tuple, obj=self.transport_map,
                       mpi_pool=mpi_pool)
        return out

class PullBackTransportMapDistribution(TransportMapDistribution):
    r""" Class for densities of the transport map type :math:`T^\sharp \pi`

    Args:
      transport_map (Maps.TriangularTransportMap): transport map :math:`T`
      base_distribution (Distributions.Distribution): distribution :math:`\pi`

    .. seealso:: :class:`TransportMapDistribution`
    """

    @counted
    def pdf(self, x, params=None, idxs_slice=slice(None), cache=None):
        r""" Evaluate :math:`T^\sharp \pi({\bf x})`

        Args:
          x (:class:`ndarray<numpy.ndarray>` [:math:`m,d`]): evaluation points
          params (dict): parameters with keys ``params_pi``, ``params_t``
          idxs_slice (slice): if precomputed values are present, this parameter
            indicates at which of the points to evaluate. The number of indices
            represented by ``idxs_slice`` must match ``x.shape[0]``.
          cache (dict): cache

        Returns:
          (:class:`ndarray<numpy.ndarray>` [:math:`m`]) -- values of :math:`T^\sharp \pi`
            at the ``x`` points.
        """
        return np.exp( self.log_pdf(x, params, idxs_slice=idxs_slice,
                                    cache=cache))

    @cached()
    @counted
    def log_pdf(self, x, params=None, idxs_slice=slice(None), cache=None):
        r""" Evaluate :math:`\log T^\sharp \pi({\bf x})`

        Args:
          x (:class:`ndarray<numpy.ndarray>` [:math:`m,d`]): evaluation points
          params (dict): parameters with keys ``params_pi``, ``params_t``
          idxs_slice (slice): if precomputed values are present, this parameter
            indicates at which of the points to evaluate. The number of indices
            represented by ``idxs_slice`` must match ``x.shape[0]``.
          cache (dict): cache

        Returns:
          (:class:`ndarray<numpy.ndarray>` [:math:`m`]) -- values of :math:`\log T^\sharp \pi`
            at the ``x`` points.
        """
        try:
            params_pi = params['params_pi']
        except (KeyError,TypeError):
            params_pi = None
        try:
            params_t = params['params_t']
        except (KeyError,TypeError):
            # idxs_slice = slice(None)
            params_t = None
        return self.transport_map.log_pullback(
            x, self.base_distribution, params_t, params_pi, idxs_slice=idxs_slice,
            cache=cache)

    @cached()
    @counted
    def grad_x_log_pdf(
            self, x, params=None, idxs_slice=slice(None), cache=None, *args, **kwargs):
        r""" Evaluate :math:`\nabla_{\bf x} \log T^\sharp \pi({\bf x})`

        Args:
          x (:class:`ndarray<numpy.ndarray>` [:math:`m,d`]): evaluation points
          params (dict): parameters with keys ``params_pi``, ``params_t``
          idxs_slice (slice): if precomputed values are present, this parameter
            indicates at which of the points to evaluate. The number of indices
            represented by ``idxs_slice`` must match ``x.shape[0]``.

        Returns:
          (:class:`ndarray<numpy.ndarray>` [:math:`m`]) -- values of
            :math:`\nabla_{\bf x} \log T^\sharp \pi` at the ``x`` points.
        """
        try:
            params_pi = params['params_pi']
        except (KeyError,TypeError):
            params_pi = None
        try:
            params_t = params['params_t']
        except (KeyError,TypeError):
            # idxs_slice = slice(None)
            params_t = None
        return self.transport_map.grad_x_log_pullback(
            x, self.base_distribution,
            params_t=params_t, params_pi=params_pi, idxs_slice=idxs_slice, cache=cache)

    @cached_tuple(['log_pdf', 'grad_x_log_pdf'])
    @counted
    def tuple_grad_x_log_pdf(
            self, x, params=None, idxs_slice=slice(None), cache=None, *args, **kwargs):
        r""" Evaluate :math:`\left(\log T^\sharp \pi({\bf x}), \nabla_{\bf x} \log T^\sharp \pi({\bf x})\right)`

        Args:
          x (:class:`ndarray<numpy.ndarray>` [:math:`m,d`]): evaluation points
          params (dict): parameters with keys ``params_pi``, ``params_t``
          idxs_slice (slice): if precomputed values are present, this parameter
            indicates at which of the points to evaluate. The number of indices
            represented by ``idxs_slice`` must match ``x.shape[0]``.

        Returns:
          (:class:`tuple`) --
            :math:`\left(\log T^\sharp \pi({\bf x}), \nabla_{\bf x} \log T^\sharp \pi({\bf x})\right)`
        """
        try:
            params_pi = params['params_pi']
        except (KeyError,TypeError):
            params_pi = None
        try:
            params_t = params['params_t']
        except (KeyError,TypeError):
            # idxs_slice = slice(None)
            params_t = None
        return self.transport_map.tuple_grad_x_log_pullback(
            x, self.base_distribution, params_t, params_pi,
            idxs_slice=idxs_slice, cache=cache)

    @cached(caching=False)
    @counted
    def hess_x_log_pdf(
            self, x, params=None, idxs_slice=slice(None), cache=None, *args, **kwargs):
        r""" Evaluate :math:`\nabla^2_{\bf x} \log T^\sharp \pi({\bf x})`

        Args:
          x (:class:`ndarray<numpy.ndarray>` [:math:`m,d,d`]): evaluation points
          params (dict): parameters with keys ``params_pi``, ``params_t``
          idxs_slice (slice): if precomputed values are present, this parameter
            indicates at which of the points to evaluate. The number of indices
            represented by ``idxs_slice`` must match ``x.shape[0]``.

        Returns:
          (:class:`ndarray<numpy.ndarray>` [:math:`m,d,d`]) -- values of
            :math:`\nabla^2_{\bf x} \log T^\sharp \pi` at the ``x`` points.
        """
        try:
            params_pi = params['params_pi']
        except (KeyError,TypeError):
            params_pi = None
        try:
            params_t = params['params_t']
        except (KeyError,TypeError):
            # idxs_slice = slice(None)
            params_t = None
        return self.transport_map.hess_x_log_pullback(
            x, self.base_distribution, params_t, params_pi,
            idxs_slice=idxs_slice, cache=cache)

    @cached(caching=False)
    @counted
    def action_hess_x_log_pdf(self, x, dx, params=None, idxs_slice=slice(None),
                              cache=None, *args, **kwargs):
        r""" Evaluate :math:`\langle\nabla^2_{\bf x} \log T^\sharp \pi({\bf x}),\delta{\bf x}\rangle`

        Args:
          x (:class:`ndarray<numpy.ndarray>` [:math:`m,d`]): evaluation points
          dx (:class:`ndarray<numpy.ndarray>` [:math:`m,d`]): direction
            on which to evaluate the Hessian
          params (dict): parameters with keys ``params_pi``, ``params_t``
          idxs_slice (slice): if precomputed values are present, this parameter
            indicates at which of the points to evaluate. The number of indices
            represented by ``idxs_slice`` must match ``x.shape[0]``.

        Returns:
          (:class:`ndarray<numpy.ndarray>` [:math:`m,d`]) -- values of
            :math:`\langle\nabla^2_{\bf x} \log T^\sharp \pi({\bf x}),\delta{\bf x}\rangle`
            at the ``x`` points.
        """
        try:
            params_pi = params['params_pi']
        except (KeyError,TypeError):
            params_pi = None
        try:
            params_t = params['params_t']
        except (KeyError,TypeError):
            # idxs_slice = slice(None)
            params_t = None
        return self.transport_map.action_hess_x_log_pullback(
            x, self.base_distribution, dx, params_t, params_pi,
            idxs_slice=idxs_slice, cache=cache)

    def map_function_base_to_target(self, f):
        r""" Given the map :math:`f` returns :math:`f\circ T^{-1}`

        Args:
          f (:class:`TransportMaps.Maps.Map<Map>`): the map :math:`f`

        Returns:
          (:class:`TransportMaps.Maps.CompositeMap<CompositeMap>`) -- :math:`f \circ T^{-1}`
        """
        return CompositeMap(f, InverseTransportMap(self.transport_map))

    def map_samples_base_to_target(self, x, mpi_pool=None):
        r""" Map input samples (assumed to be from :math:`\pi`) to the corresponding samples from :math:`T^\sharp \pi`.

        Args:
          x (:class:`ndarray<numpy.ndarray>` [:math:`m,d`]): input samples
          mpi_pool (:class:`mpi_map.MPI_Pool<mpi_map.MPI_Pool>`): pool of processes

        Returns:
          (:class:`ndarray<numpy.ndarray>` [:math:`m,d`]) -- corresponding samples
        """
        scatter_tuple = (['x'], [x])
        out = mpi_map("inverse", scatter_tuple=scatter_tuple, obj=self.transport_map,
                       mpi_pool=mpi_pool)
        return out

    def map_samples_target_to_base(self, x, mpi_pool=None):
        r""" Map input samples assumed to be from :math:`T^\sharp \pi` to the corresponding samples from :math:`\pi`.

        Args:
          x (:class:`ndarray<numpy.ndarray>` [:math:`m,d`]): input samples
          mpi_pool (:class:`mpi_map.MPI_Pool<mpi_map.MPI_Pool>`): pool of processes

        Returns:
          (:class:`ndarray<numpy.ndarray>` [:math:`m,d`]) -- corresponding samples
        """
        scatter_tuple = (['x'], [x])
        out = mpi_map("evaluate", scatter_tuple=scatter_tuple, obj=self.transport_map,
                       mpi_pool=mpi_pool)
        return out
