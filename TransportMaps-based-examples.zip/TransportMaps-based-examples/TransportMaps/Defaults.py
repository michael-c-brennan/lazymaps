#
# This file is part of TransportMaps.
#
# TransportMaps is free software: you can redistribute it and/or modify
# it under the terms of the GNU Lesser General Public License as published by
# the Free Software Foundation, either version 3 of the License, or
# (at your option) any later version.
#
# TransportMaps is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU Lesser General Public License for more details.
#
# You should have received a copy of the GNU Lesser General Public License
# along with TransportMaps.  If not, see <http://www.gnu.org/licenses/>.
#
# Transport Maps Library
# Copyright (C) 2015-2018 Massachusetts Institute of Technology
# Uncertainty Quantification group
# Department of Aeronautics and Astronautics
#
# Authors: Transport Map Team
# Website: transportmaps.mit.edu
# Support: transportmaps.mit.edu/qa/
#

import numpy as np
import SpectralToolbox.Spectral1D as S1D
import TransportMaps as TM
import TransportMaps.Maps.Functionals as FUNC
import TransportMaps.Maps as MAPS

__all__ = [
    # Deprecated
    'Default_IsotropicIntegratedExponentialTriangularTransportMap',
    'Default_IsotropicIntegratedExponentialDiagonalTransportMap',
    'Default_IsotropicIntegratedSquaredTriangularTransportMap',
    'Default_IsotropicIntegratedSquaredDiagonalTransportMap',
    'Default_IsotropicMonotonicLinearSpanTriangularTransportMap',
    'Default_IsotropicLinearSpanTriangularTransportMap',
    'Default_LinearSpanTriangularTransportMap'
]

@TM.deprecate(
    'Default_IsotropicIntegratedExponentialTriangularTransportMap',
    '3.0',
    'Use Maps.assemble_IsotropicIntegratedExponentialTriangularTransportMap instead.'
)
def Default_IsotropicIntegratedExponentialTriangularTransportMap(
        *args, **kwargs
):
    return MAPS.assemble_IsotropicIntegratedExponentialTriangularTransportMap(*args, **kwargs)

    
@TM.deprecate(
    'Default_IsotropicIntegratedExponentialDiagonalTransportMap',
    '3.0',
    'Use Maps.assemble_IsotropicIntegratedExponentialDiagonalTransportMap instead.'
)
def Default_IsotropicIntegratedExponentialDiagonalTransportMap(
        *args, **kwargs
):
    return MAPS.assemble_IsotropicIntegratedExponentialDiagonalTransportMap(*args, **kwargs)

    
@TM.deprecate(
    'Default_IsotropicIntegratedSquaredTriangularTransportMap',
    '3.0',
    'Use Maps.assemble_IsotropicIntegratedSquaredTriangularTransportMap instead.'
)
def Default_IsotropicIntegratedSquaredTriangularTransportMap(
        *args, **kwargs
):
    return MAPS.assemble_IsotropicIntegratedSquaredTriangularTransportMap(*args, **kwargs)

    
@TM.deprecate(
    'Default_IsotropicIntegratedSquaredDiagonalTransportMap',
    '3.0',
    'Use Maps.assemble_IsotropicIntegratedSquaredDiagonalTransportMap instead.'
)
def Default_IsotropicIntegratedSquaredDiagonalTransportMap(
        *args, **kwargs
):
    return MAPS.assemble_IsotropicIntegratedSquaredDiagonalTransportMap(*args, **kwargs)


@TM.deprecate(
    'Default_IsotropicMonotonicLinearSpanTriangularTransportMap',
    '3.0',
    'Use Maps.assemble_IsotropicLinearSpanTriangularTransportMap instead'
)
def Default_IsotropicMonotonicLinearSpanTriangularTransportMap(
        *args, **kwargs
):
    return MAPS.assemble_LinearSpanTriangularTransportMap(*args, **kwargs)


@TM.deprecate(
    'Default_IsotropicLinearSpanTriangularTransportMap',
    '3.0',
    'Use Maps.assemble_IsotropicLinearSpanTriangularMap instead'
)
def Default_IsotropicLinearSpanTriangularTransportMap(
        *args, **kwargs
):
    return MAPS.assemble_IsotropicLinearSpanTriangularMap(*args, **kwargs)


@TM.deprecate(
    'Default_LinearSpanTriangularTransportMap',
    '3.0',
    'Use Maps.assemble_LinearSpanTriangularMap instead'
)
def Default_LinearSpanTriangularTransportMap(
        *args, **kwargs
):
    return MAPS.assemble_LinearSpanTriangularMap(*args, **kwargs)

