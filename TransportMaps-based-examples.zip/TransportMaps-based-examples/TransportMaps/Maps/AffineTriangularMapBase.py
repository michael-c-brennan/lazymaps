#!/usr/bin/env python

#
# This file is part of TransportMaps.
#
# TransportMaps is free software: you can redistribute it and/or modify
# it under the terms of the GNU Lesser General Public License as published by
# the Free Software Foundation, either version 3 of the License, or
# (at your option) any later version.
#
# TransportMaps is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU Lesser General Public License for more details.
#
# You should have received a copy of the GNU Lesser General Public License
# along with TransportMaps.  If not, see <http://www.gnu.org/licenses/>.
#
# Transport Maps Library
# Copyright (C) 2015-2018 Massachusetts Institute of Technology
# Uncertainty Quantification group
# Department of Aeronautics and Astronautics
#
# Author: Transport Map Team
# Website: transportmaps.mit.edu
# Support: transportmaps.mit.edu/qa/
#

import numpy as np
import numpy.linalg as npla
import scipy.optimize as sciopt
import scipy.linalg as scila
import sys
import scipy.sparse as scisp
import copy as cp

from TransportMaps.Misc import \
    required_kwargs, \
    deprecate, counted, cached, get_sub_cache
from .AffineMapBase import AffineMap

__all__ = [
    'AffineTriangularMap',
    # Deprecated
    'LinearTriangularMap'
]
class AffineTriangularMap(AffineMap):
    r""" Affine map :math:`T({\bf x})={\bf c} + {\bf L}{\bf x}` where :math:`L` is triangular
    """
    def __init__(self, **kwargs):
        r"""
        Optional Kwargs:
          dim (int): dimension :math:`d`. If provided the map is set to the identity.
          c (:class:`ndarray<numpy.ndarray>` [:math:`d`]): term :math:`{\bf c}`
          L (:class:`ndarray<numpy.ndarray>` [:math:`d,d`]): term :math:`{\bf L}`
          lower (bool): whether the map is lower triangular (``True``)
            or upper triangular (``False``). Default: ``True``

        Raises:
          ValueError: if ``dim`` and (``c``, ``L``) are provided
            at the same time.
        """
        dim   = kwargs.get('dim')
        c     = kwargs.get('c')
        L     = kwargs.get('L')
        lower = kwargs.get('lower', True)
        if dim is not None and (c is not None or L is not None):
            raise ValueError(
                "The arguments dim and (c, L) are mutually exclusive.")
        if dim is not None:
            c = np.zeros(dim)
            L = np.eye(dim)
        L = np.tril(L) if lower else np.triu(L)
        kwargs['c'] = c
        kwargs['L'] = L
        super(AffineTriangularMap, self).__init__(**kwargs)

    def regression(self, t, tparams=None, d=None, qtype=None, qparams=None,
                   x=None, w=None, regularization=None, **kwargs):
        r""" Compute :math:`{\bf a}^* = \arg\min_{\bf a} \Vert T - T({\bf a}) \Vert_{\pi}`.

        This regression problem can be completely decoupled if the measure
        is a product measure, obtaining

        .. math::

           a^{(i)*} = \arg\min_{\bf a^{(i)}} \Vert T_i - T_i({\bf a}^{(i)}) \Vert_{\pi_i}

        Args:
          t (function or :class:`ndarray<numpy.ndarray>` [:math:`m`]): function
            :math:`t` with signature ``t(x)`` or its functions values
          tparams (dict): parameters for function :math:`t`
          d (Distribution): distribution :math:`\pi`
          qtype (int): quadrature type to be used for the approximation of
            :math:`\mathbb{E}_{\pi}`
          qparams (object): parameters necessary for the construction of the
            quadrature
          x (:class:`ndarray<numpy.ndarray>` [:math:`m,d`]): quadrature points
            used for the approximation of :math:`\mathbb{E}_{\pi}`
          w (:class:`ndarray<numpy.ndarray>` [:math:`m`]): quadrature weights
            used for the approximation of :math:`\mathbb{E}_{\pi}`
          regularization (dict): defines the regularization to be used.
            If ``None``, no regularization is applied.
            If key ``type=='L2'`` then applies Tikonhov regularization with
            coefficient in key ``alpha``.

        Returns:
          (:class:`tuple<tuple>` (:class:`ndarray<numpy.ndarray>` [:math:`N`],
          :class:`list<list>`)) -- containing the :math:`N` coefficients and
          log information.

        .. note:: the resulting coefficients :math:`{\bf a}` are automatically
           set at the end of the optimization. Use :func:`get_coeffs` in order
           to retrieve them.

        .. note:: The parameters ``(qtype,qparams)`` and ``(x,w)`` are mutually
           exclusive, but one pair of them is necessary.
        """
        if (x is None) and (w is None):
            (x,w) = d.quadrature(qtype, qparams)
        if isinstance(t, np.ndarray):
            T = t
        else:
            T = t(x)
        # Build weighted invsersion matrix
        X = np.hstack( (np.ones((x.shape[0],1)), x) )    
        XW = X * w[:,np.newaxis]
        P = np.dot(XW.T, X)
        # Regularization
        if regularization is not None:
            if regularization['type'] == 'L2':
                P += regularization['alpha'] * np.eye(P.shape[0])
            else:
                raise NotImplementedError(
                    "Regularization type %s not implemented." % regularization['type'])
        # Compute cholesky decomposition of inversion matrix
        U = scila.cholesky(P)
        # Iterate over the dimensions and solve for each component
        # (enforcing lower triangular structure)
        cnst = np.zeros(self.dim)
        lin = np.zeros((self.dim,self.dim))
        for i in range(self.dim):
            XWi = XW[:,:i+2]
            Ui = U[:i+2,:i+2]
            Ti = T[:,i]
            # Compute right hand side
            rhs = np.dot(XWi.T, Ti)
            # Solve system
            beta = scila.solve_triangular(Ui, rhs, lower=False, trans='T')
            beta = scila.solve_triangular(Ui, beta, lower=False)
            # Write coefficients
            cnst[i] = beta[0]
            lin[i,:i+1] = beta[1:]
        self.c = cnst
        self.L = lin
        log = {'success': True}
        return (self.coeffs, log)

class LinearTriangularMap(AffineTriangularMap):
    @deprecate(
        'LinearTriangularMap',
        '3.0',
        'Use Maps.AffineTriangularMap instead.'
    )
    def __init__(self, dim=None, constantTerm=None, linearTerm=None, lower=True):
        super(LinearTriangularMap, self).__init__(
            dim   = dim,
            c     = constantTerm,
            L     = linearTerm,
            lower = lower
        )
