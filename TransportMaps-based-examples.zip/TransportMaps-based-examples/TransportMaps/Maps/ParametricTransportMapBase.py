#
# This file is part of TransportMaps.
#
# TransportMaps is free software: you can redistribute it and/or modify
# it under the terms of the GNU Lesser General Public License as published by
# the Free Software Foundation, either version 3 of the License, or
# (at your option) any later version.
#
# TransportMaps is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU Lesser General Public License for more details.
#
# You should have received a copy of the GNU Lesser General Public License
# along with TransportMaps.  If not, see <http://www.gnu.org/licenses/>.
#
# Transport Maps Library
# Copyright (C) 2015-2018 Massachusetts Institute of Technology
# Uncertainty Quantification group
# Department of Aeronautics and Astronautics
#
# Authors: Transport Map Team
# Website: transportmaps.mit.edu
# Support: transportmaps.mit.edu/qa/
#

import logging
import numpy as np
import numpy.linalg as npla
import scipy.linalg as scila
import scipy.optimize as sciopt
import dill

from TransportMaps.Misc import mpi_map, mpi_map_alloc_dmem, \
    SumChunkReduce, TupleSumChunkReduce, \
    required_kwargs, \
    cached, cached_tuple, counted, get_sub_cache, \
    deprecate, \
    distributed_sampling, \
    mpi_map, mpi_bcast_dmem, mpi_map_alloc_dmem
from TransportMaps.Routines import \
    kl_divergence, grad_a_kl_divergence, hess_a_kl_divergence, \
    tuple_grad_a_kl_divergence, action_hess_a_kl_divergence, \
    storage_hess_a_kl_divergence, action_stored_hess_a_kl_divergence
import TransportMaps.FiniteDifference as FD
from TransportMaps.Maps.Functionals.ProductDistributionParametricPullbackComponentFunctionBase \
    import ProductDistributionParametricPullbackComponentFunction
from .ParametricMapBase import ParametricMap
from .TransportMapBase import TransportMap

__all__ = [
    'ParametricTransportMap',
]

nax = np.newaxis

class ParametricTransportMap(ParametricMap, TransportMap):
    r"""Transport map :math:`T[{\bf a}]({\bf x}): \mathbb{R}^n \times \mathbb{R}^{d_x}\rightarrow\mathbb{R}^{d_x}`.
    """
    @required_kwargs('dim')
    def __init__(self, **kwargs):
        kwargs['dim_in'] = kwargs['dim']
        kwargs['dim_out'] = kwargs['dim']
        super(ParametricTransportMap, self).__init__(**kwargs)

    @counted
    def grad_a_inverse(self, x, precomp=None, idxs_slice=slice(None)):
        r""" [Abstract] Compute :math:`\nabla_{\bf a} T^{-1}[{\bf a}]({\bf x})`

        Args:
          x (:class:`ndarray<numpy.ndarray>` [:math:`m,d`]): evaluation points
          precomp (:class:`dict<dict>`): dictionary of precomputed values
          idxs_slice (slice): if precomputed values are present, this parameter
            indicates at which of the points to evaluate. The number of indices
            represented by ``idxs_slice`` must match ``x.shape[0]``.

        Returns:
           (:class:`ndarray<numpy.ndarray>` [:math:`m,d,N`]) --
              :math:`\nabla_{\bf a} T^{-1}[{\bf a}]({\bf x})`

        Raises:
           ValueError: if :math:`d` does not match the dimension of the transport map.
        """
        raise NotImplementedError("Abstract method")

    @cached()
    @counted
    def grad_a_log_det_grad_x(self, x, precomp=None, idxs_slice=slice(None),
                              *args, **kwargs):
        r""" [Abstract] Compute: :math:`\nabla_{\bf a} \log \det \nabla_{\bf x} T[{\bf a}]({\bf x})`.

        Args:
           x (:class:`ndarray<numpy.ndarray>` [:math:`m,d`]): evaluation points
           precomp (:class:`dict<dict>`): dictionary of precomputed values
           idxs_slice (slice): if precomputed values are present, this parameter
            indicates at which of the points to evaluate. The number of indices
            represented by ``idxs_slice`` must match ``x.shape[0]``.

        Returns:
           (:class:`ndarray<numpy.ndarray>` [:math:`m,N`]) --
             :math:`\nabla_{\bf a} \log \det \nabla_{\bf x} T[{\bf a}]({\bf x})`
             at every evaluation point

        .. seealso:: :func:`log_det_grad_x`
        """
        raise NotImplementedError("Abstract method")

    @cached()
    @counted
    def hess_a_log_det_grad_x(self, x, precomp=None, idxs_slice=slice(None),
                              *args, **kwargs):
        r""" [Abstract] Compute: :math:`\nabla^2_{\bf a} \log \det \nabla_{\bf x} T[{\bf a}]({\bf x})`.

        Args:
           x (:class:`ndarray<numpy.ndarray>` [:math:`m,d`]): evaluation points
           precomp (:class:`dict<dict>`): dictionary of precomputed values
           idxs_slice (slice): if precomputed values are present, this parameter
            indicates at which of the points to evaluate. The number of indices
            represented by ``idxs_slice`` must match ``x.shape[0]``.

        Returns:
           (:class:`ndarray<numpy.ndarray>` [:math:`m,N,N`]) --
           :math:`\nabla^2_{\bf a} \log \det \nabla_{\bf x} T[{\bf a}]({\bf x})`
           at every evaluation point

        .. seealso:: :func:`log_det_grad_x` and :func:`grad_a_log_det_grad_x`
        """
        raise NotImplementedError("Abstract method")

    def _evaluate_grad_a_log_pullback(self, gxlpdf, ga_list, galdgx):
        out = np.zeros((gxlpdf.shape[0],self.n_coeffs))
        start = 0
        for k,grad in enumerate(ga_list):
            stop = start + grad.shape[1]
            out[:,start:stop] = gxlpdf[:,k,nax] * grad
            start = stop
        out += galdgx
        return out
        
    @cached([('pi',None),('t',None)])
    @counted
    def grad_a_log_pullback(self, x, pi, params_t=None, params_pi=None,
                            idxs_slice=slice(None), cache=None):
        r""" Compute :math:`\nabla_{\bf a}[ \log \pi \circ T({\bf x,a}) + \log \vert\det \nabla_{\bf x}T({\bf x,a})\vert ]`.

        Args:
          x (:class:`ndarray<numpy.ndarray>` [:math:`m,d`]): evaluation points
          pi (:class:`Distributions.Distribution`): distribution to be pulled back       
          params_t (dict): parameters for the evaluation of :math:`T_{\bf a}`
          params_pi (dict): parameters for the evaluation of :math:`\pi`
          idxs_slice (slice): if precomputed values are present, this parameter
            indicates at which of the points to evaluate. The number of indices
            represented by ``idxs_slice`` must match ``x.shape[0]``.

        Returns:
           (:class:`ndarray<numpy.ndarray>` [:math:`m,N`]) --
           :math:`\nabla_{\bf a}\left[ \log \pi \circ T({\bf x,a}) + \log \vert\det \nabla_{\bf x}T({\bf x,a})\vert \right]`
           at every evaluation point

        Raises:
           ValueError: if :math:`d` does not match the dimension of the transport map.

        .. seealso:: :func:`grad_a`, :func:`grad_a_log_det_grad_x`.
        """
        if x.shape[1] != self.dim_in:
            raise ValueError("dimension mismatch")
        # Init sub-cache if necessary
        pi_cache, t_cache = get_sub_cache(cache, ('pi',None), ('t',None))
        ev = self.evaluate(x, precomp=params_t, idxs_slice=idxs_slice, cache=t_cache)
        ga_list = self.grad_a(x, precomp=params_t, idxs_slice=idxs_slice, cache=t_cache)
        gxlpdf = pi.grad_x_log_pdf(
            ev, params=params_pi, idxs_slice=idxs_slice, cache=pi_cache)
        galdgx = self.grad_a_log_det_grad_x(
            x, precomp=params_t, idxs_slice=idxs_slice, cache=t_cache)
        return self._evaluate_grad_a_log_pullback(gxlpdf, ga_list, galdgx)

    @cached_tuple(['log_pullback', 'grad_a_log_pullback'],[('pi',None),('t',None)])
    @counted
    def tuple_grad_a_log_pullback(self, x, pi, params_t=None, params_pi=None,
                                  idxs_slice=slice(None), cache=None):
        r""" Compute :math:`\left(\log \pi \circ T({\bf x,a}) + \log \vert\det \nabla_{\bf x}T({\bf x,a}),\nabla_{\bf a}[ \log \pi \circ T({\bf x,a}) + \log \vert\det \nabla_{\bf x}T({\bf x,a})\vert ]\right)`.

        Args:
          x (:class:`ndarray<numpy.ndarray>` [:math:`m,d`]): evaluation points
          pi (:class:`Distributions.Distribution`): distribution to be pulled back        
          params_t (dict): parameters for the evaluation of :math:`T_{\bf a}`
          params_pi (dict): parameters for the evaluation of :math:`\pi`
          idxs_slice (slice): if precomputed values are present, this parameter
            indicates at which of the points to evaluate. The number of indices
            represented by ``idxs_slice`` must match ``x.shape[0]``.
          cache (dict): cache

        Returns:
           (:class:`tuple`) --
            :math:`\left(\log \pi \circ T({\bf x,a}) + \log \vert\det \nabla_{\bf x}T({\bf x,a}),\nabla_{\bf a}[ \log \pi \circ T({\bf x,a}) + \log \vert\det \nabla_{\bf x}T({\bf x,a})\vert ]\right)`

        Raises:
           ValueError: if :math:`d` does not match the dimension of the transport map.

        .. seealso:: :func:`grad_a`, :func:`grad_a_log_det_grad_x`.
        """
        if x.shape[1] != self.dim_in:
            raise ValueError("dimension mismatch")
        # Init sub-cache if necessary
        pi_cache, t_cache = get_sub_cache(cache, ('pi',None), ('t',None))
        ev = self.evaluate(x, precomp=params_t, idxs_slice=idxs_slice, cache=t_cache)
        ldgx = self.log_det_grad_x(x, precomp=params_t, idxs_slice=idxs_slice, cache=t_cache)
        ga_list = self.grad_a(x, precomp=params_t, idxs_slice=idxs_slice, cache=t_cache)
        galdgx = self.grad_a_log_det_grad_x(
            x, precomp=params_t, idxs_slice=idxs_slice, cache=t_cache)
        lpdf, gxlpdf = pi.tuple_grad_x_log_pdf(
            ev, params=params_pi, idxs_slice=idxs_slice, cache=pi_cache)
        return ( self._evaluate_log_transport(lpdf, ldgx),
                 self._evaluate_grad_a_log_pullback(gxlpdf, ga_list, galdgx) )

    @cached([('pi',None),('t',None)], False)
    @counted
    def hess_a_log_pullback(self, x, pi, params_t=None, params_pi=None,
                            idxs_slice=slice(None), cache=None ):
        r""" Compute :math:`\nabla^2_{\bf a}[ \log \pi \circ T({\bf x,a}) + \log \vert\det \nabla_{\bf x}T({\bf x,a})\vert ]`.

        Args:
          x (:class:`ndarray<numpy.ndarray>` [:math:`m,d`]): evaluation points
          pi (:class:`Distributions.Distribution`): distribution to be pulled back        
          params_t (dict): parameters for the evaluation of :math:`T_{\bf a}`
          params_pi (dict): parameters for the evaluation of :math:`\pi`
          idxs_slice (slice): if precomputed values are present, this parameter
            indicates at which of the points to evaluate. The number of indices
            represented by ``idxs_slice`` must match ``x.shape[0]``.
          cache (dict): cache

        Returns:
           (:class:`ndarray<numpy.ndarray>` [:math:`m,N,N`]) --
           :math:`\nabla^2_{\bf a}\left[ \log \pi \circ T({\bf x,a}) + \log \vert\det \nabla_{\bf x}T({\bf x,a})\vert \right]`
           at every evaluation point

        Raises:
           ValueError: if :math:`d` does not match the dimension of the transport map.

        .. seealso:: :func:`grad_a`, :func:`hess_a`, :func:`grad_x_log_pullback`, :func:`hess_x_log_pullback`, :func:`hess_a_log_det_grad_x`.
        """
        if x.shape[1] != self.dim_in:
            raise ValueError("dimension mismatch")
        from TransportMaps.Distributions.ProductDistributionBase import ProductDistribution
        if issubclass(type(pi), ProductDistribution):
            n = x.shape[0]
            hess_a_sum = np.zeros((n,self.n_coeffs,self.n_coeffs))
            # currently not using parallel implementation (batch_size_list, mpi_pool_list)
            # currently using params_t and params_pi assuming None
            start_j = 0
            for i,(a,avars) in enumerate(zip(self.approx_list,self.active_vars)):
                pi_i = pi.get_component([i])
                pS_i = ProductDistributionParametricPullbackComponentFunction(a, pi_i)
                stop_j = start_j + a.n_coeffs
                hess_a_sum[np.ix_(range(n), range(start_j,stop_j), range(start_j,stop_j))] += pS_i.hess_a(x[:,avars])
                start_j = stop_j
            return hess_a_sum
        else:
            # Init sub-cache if necessary
            pi_cache, t_cache = get_sub_cache(cache, ('pi',None), ('t',None))
       	    xval = self.evaluate(x, precomp=params_t, idxs_slice=idxs_slice, cache=t_cache)
            grad_list = self.grad_a(x, precomp=params_t, idxs_slice=idxs_slice,
                                cache=t_cache) # List of d (n x m) arrays
            hess_list = self.hess_a(x, precomp=params_t, idxs_slice=idxs_slice,
                                cache=t_cache) # List of d (n x m x m) arrays
            dxlogpull = pi.grad_x_log_pdf(
                xval, params=params_pi, idxs_slice=idxs_slice, cache=pi_cache) # (n x d) array
            dx2logpull = pi.hess_x_log_pdf(
                xval, params=params_pi,
                idxs_slice=idxs_slice, cache=pi_cache) # (n x d x d) array
            out = np.empty((x.shape[0],self.n_coeffs,
                           self.n_coeffs)) # Initialized by first addend
            # First addend
            start_j = 0
            for j in range(self.dim_out):
                g = grad_list[j]
                stop_j = start_j + g.shape[1]
                start_k = 0
                for k in range(self.dim_out):
                    h = grad_list[k]
                    stop_k = start_k + h.shape[1]
                    tmp = dx2logpull[:,j,k,nax] * g
                    out[:,start_j:stop_j,start_k:stop_k] = tmp[:,:,nax] * h[:,nax,:]
                    start_k = stop_k
                start_j = stop_j
            # Second addend
            start = 0
            for k,hess in enumerate(hess_list):
                stop = start + hess.shape[1]
                out[:,start:stop,start:stop] += dxlogpull[:,k,nax,nax] * hess
                start = stop
            # Add Hessian of the log determinant term
            out += self.hess_a_log_det_grad_x(x, precomp=params_t,
                                          idxs_slice=idxs_slice, cache=t_cache)
            return out

    def grad_a_hess_x_log_pullback(self, pi, x, params_t=None, params_pi=None,
                            idxs_slice=slice(None) ):
        r""" Compute :math:`\nabla_{\bf a} \nabla^2_{\bf x}[ \log \pi \circ T({\bf x,a}) + \log \vert\det \nabla_{\bf x}T({\bf x,a})\vert ]`.

        Args:
          pi (:class:`Distributions.Distribution`): distribution to be pulled back
          x (:class:`ndarray<numpy.ndarray>` [:math:`m,d`]): evaluation points
          params_t (dict): parameters for the evaluation of :math:`T_{\bf a}`
          params_pi (dict): parameters for the evaluation of :math:`\pi`
          idxs_slice (slice): if precomputed values are present, this parameter
            indicates at which of the points to evaluate. The number of indices
            represented by ``idxs_slice`` must match ``x.shape[0]``.

        Returns:
           (:class:`ndarray<numpy.ndarray>` [:math:`m,N,d,d`]) --
           :math:`\nabla_{\bf a} \nabla^2_{\bf x}\left[ \log \pi \circ T({\bf x,a}) + \log \vert\det \nabla_{\bf x}T({\bf x,a})\vert \right]`
           at every evaluation point

        Raises:
           ValueError: if :math:`d` does not match the dimension of the transport map.

        .. seealso:: :func:`grad_a`, :func:`hess_a`, :func:`grad_x_log_pullback`, :func:`hess_x_log_pullback`, :func:`hess_a_log_det_grad_x`.
        """
        from TransportMaps.Distributions.ProductDistributionBase import ProductDistribution
        if issubclass(type(pi), ProductDistribution):
            n = x.shape[0]
            grad_a_hess_x_sum = np.zeros((n,self.n_coeffs,self.dim,self.dim))
            # currently not using parallel implementation (batch_size_list, mpi_pool_list)
            # currently using params_t and params_pi assuming None
            start_j = 0
            for i,(a,avars) in enumerate(zip(self.approx_list,self.active_vars)):
                pi_i = pi.get_component([i])
                pS_i = ProductDistributionParametricPullbackComponentFunction(a, pi_i)
                stop_j = start_j + a.n_coeffs
                grad_a_hess_x_sum[np.ix_(range(n), range(start_j,stop_j), avars, avars)] += pS_i.grad_a_hess_x(x[:,avars])
                start_j = stop_j
            return grad_a_hess_x_sum
        else:
            print('not implemented yet')

    @cached([('pi',None),('t',None)], False)
    @counted
    def action_hess_a_log_pullback(
            self, x, pi, da, params_t=None, params_pi=None, idxs_slice=slice(None),
            cache=None):
        r""" Compute :math:`\langle\nabla^2_{\bf a}[ \log \pi \circ T({\bf x,a}) + \log \vert\det \nabla_{\bf x}T({\bf x,a})\vert ], \delta{\bf a}\rangle`.

        Args:
          x (:class:`ndarray<numpy.ndarray>` [:math:`m,d`]): evaluation points
          pi (:class:`Distributions.Distribution`): distribution to be pulled back       
          da (:class:`ndarray<numpy.ndarray>` [:math:`N`]): direction
            on which to evaluate the Hessian
          params_t (dict): parameters for the evaluation of :math:`T_{\bf a}`
          params_pi (dict): parameters for the evaluation of :math:`\pi`
          idxs_slice (slice): if precomputed values are present, this parameter
            indicates at which of the points to evaluate. The number of indices
            represented by ``idxs_slice`` must match ``x.shape[0]``.
          cache (dict): cache

        Returns:
           (:class:`ndarray<numpy.ndarray>` [:math:`m,N,N`]) --
           :math:`\langle\nabla^2_{\bf a}[ \log \pi \circ T({\bf x,a}) + \log \vert\det \nabla_{\bf x}T({\bf x,a})\vert ], \delta{\bf x}\rangle`
           at every evaluation point

        Raises:
           ValueError: if :math:`d` does not match the dimension of the transport map.

        .. seealso:: :func:`grad_a`, :func:`hess_a`, :func:`grad_x_log_pullback`, :func:`hess_x_log_pullback`, :func:`hess_a_log_det_grad_x`.
        """
        if x.shape[1] != self.dim_in:
            raise ValueError("dimension mismatch")
        # Init sub-cache if necessary
        pi_cache, t_cache = get_sub_cache(cache, ('pi',None), ('t',None))
        m = x.shape[0]
        xval = self.evaluate(x, precomp=params_t, idxs_slice=idxs_slice, cache=t_cache)

        # First addend
        grad_list = self.grad_a(x, precomp=params_t, idxs_slice=idxs_slice,
                                cache=t_cache) # List of d (m x n) arrays
        dx = np.zeros((m, self.dim_out))
        start = 0
        for j, g in enumerate(grad_list):
            stop = start + g.shape[1]
            dx[:,j] = np.dot(g, da[start:stop])
            start = stop
        ahxlpdf = pi.action_hess_x_log_pdf(
            xval, dx, params=params_pi, idxs_slice=idxs_slice, cache=pi_cache) # m x d
        A = np.zeros((m, self.n_coeffs)) # m x N
        start = 0
        for j, g in enumerate(grad_list):
            stop = start + g.shape[1]
            A[:,start:stop] = g * ahxlpdf[:,[j]]
            start = stop

        # Second addend
        action_hess_list = self.action_hess_a(
            x, da, precomp=params_t, idxs_slice=idxs_slice,
            cache=t_cache) # list d (m x n)
        dxlogpull = pi.grad_x_log_pdf(
            xval, params=params_pi, idxs_slice=idxs_slice, cache=pi_cache) # (m x d) array
        B = np.zeros((m, self.n_coeffs))
        start = 0
        for j, ah in enumerate(action_hess_list):
            stop = start + ah.shape[1]
            B[:,start:stop] = dxlogpull[:,[j]] * ah
            start = stop
        
        # Add Hessian of the log determinant term
        C = self.action_hess_a_log_det_grad_x(
            x, da, precomp=params_t, idxs_slice=idxs_slice, cache=t_cache)
        return A + B + C

    @counted
    def grad_a_log_pushforward(self, x, pi, params_t=None, params_pi=None,
                               idxs_slice=slice(None), *args, **kwargs):
        r""" Compute :math:`\nabla_{\bf a}\left[ \log \pi \circ T^{-1}({\bf x,a}) + \log \det \nabla_{\bf x}T^{-1}({\bf x,a}) \right]` .

        For :math:`{\bf z} = T^{-1}({\bf x,a})`,

        .. math::
        
           \nabla_{\bf a}\left[ \log \pi \circ T^{-1}({\bf x,a}) + \log \det \nabla_{\bf x}T^{-1}({\bf x,a}) \right] &= \nabla_{\bf a} T({\bf z, a})^\top \nabla_{\bf x} T({\bf z,a})^{-\top} \left( \sum_{i=1}^d \frac{\nabla_{\bf x}\partial_{x_i}T_i({\bf z}_{1:i},{\bf a}_i)}{\partial_{x_i}T_i({\bf z}_{1:i},{\bf a}_i)} - \nabla_{\bf x}\log\pi \right) \\
           & - \sum_{i=1}^d \frac{\nabla_{\bf a}\partial_{x_i}T_i({\bf z}_{1:i},{\bf a}_i)}{\partial_{x_i}T_i({\bf z}_{1:i},{\bf a}_i)}
           

        Args:
          x (:class:`ndarray<numpy.ndarray>` [:math:`m,d`]): evaluation points
          pi (:class:`Distributions.Distribution`): distribution to be pulled back        
          params_t (dict): parameters for the evaluation of :math:`T_{\bf a}`
          params_pi (dict): parameters for the evaluation of :math:`\pi`
          idxs_slice (slice): if precomputed values are present, this parameter
            indicates at which of the points to evaluate. The number of indices
            represented by ``idxs_slice`` must match ``x.shape[0]``.

        Returns:
           (:class:`ndarray<numpy.ndarray>` [:math:`m,N`]) --
           :math:`\nabla_{\bf a}\left[ \log \pi \circ T^{-1}({\bf x,a}) + \log \vert\det \nabla_{\bf x}T^{-1}({\bf x,a})\vert \right]`
           at every evaluation point

        Raises:
           ValueError: if :math:`d` does not match the dimension of the transport map.

        .. seealso:: :func:`grad_a_inverse`, :func:`grad_a_log_det_grad_x_inverse`.
        """
        xinv = self.inverse(x, params_t, idxs_slice=idxs_slice)
        gx = self.grad_x(xinv) # Lower triangular
        ga_list = self.grad_a(xinv) # List of diagonal blocks
        out = np.zeros( (x.shape[0], self.n_coeffs) )
        # Solve linear system
        tmp = self.grad_x_log_det_grad_x(xinv)
        tmp -= pi.grad_x_log_pdf(xinv)
        for i in range(x.shape[0]):
            scila.solve_triangular(gx[i,:,:], tmp[i,:],
                                   lower=True, trans='T', overwrite_b=True)
        # Finish computing first term
        start = 0
        for d, ga in enumerate(ga_list):
            stop = start + ga.shape[1]
            out[:,start:stop] = ga * tmp[:,d,nax]
            start += ga.shape[1]
        # Add second term
        out -= self.grad_a_log_det_grad_x(xinv)
        return out

    @staticmethod
    def generate_quadrature(
            d1, x, w, qtype, qparams, mpi_pool
    ):
        if (x is None) and (w is None):
            if qtype == 0: # Sample separately on the cores (lower memory)
                (x, w) = distributed_sampling(
                    d1, 0, qparams, mpi_pool=mpi_pool)
            else:
                (x, w) = d1.quadrature(qtype, qparams, mpi_pool=mpi_pool)
                def alloc_quadrature(x, w):
                    return (x, w)
                (x, w) = mpi_map_alloc_dmem(
                    alloc_quadrature,
                    scatter_tuple=(['x','w'],[x,w]),
                    dmem_key_out_list=['x', 'w'],
                    mpi_pool=mpi_pool)
        else:
            def alloc_quadrature(x, w):
                return (x, w)
            (x, w) = mpi_map_alloc_dmem(
                alloc_quadrature,
                scatter_tuple=(['x','w'],[x,w]),
                dmem_key_out_list=['x', 'w'],
                mpi_pool=mpi_pool)
        return (x, w)
                
    def minimize_kl_divergence(self, d1, d2,
                               qtype=None, qparams=None,
                               x=None, w=None,
                               params_d1=None, params_d2=None,
                               x0=None,
                               regularization=None,
                               tol=1e-4, maxit=100, ders=2,
                               fungrad=False, hessact=False,
                               precomp_type='uni',
                               batch_size=None,
                               mpi_pool=None,
                               grad_check=False, hess_check=False):
        r""" [Abstract] Compute: :math:`{\bf a}^* = \arg\min_{\bf a}\mathcal{D}_{KL}\left(\pi_1, \pi_{2,{\bf a}}\right)`

        Args:
          d1 (Distribution): distribution :math:`\pi_1`
          d2 (Distribution): distribution :math:`\pi_2`
          qtype (int): quadrature type number provided by :math:`\pi`
          qparams (object): inputs necessary to the generation of the selected
            quadrature
          x (:class:`ndarray<numpy.ndarray>` [:math:`m,d`]): quadrature points
          w (:class:`ndarray<numpy.ndarray>` [:math:`m`]): quadrature weights
          params1 (dict): parameters for distribution :math:`\pi_1`
          params2 (dict): parameters for distribution :math:`\pi_2`
          x0 (:class:`ndarray<numpy.ndarray>` [:math:`N`]): coefficients to be used
            as initial values for the optimization
          regularization (dict): defines the regularization to be used.
            If ``None``, no regularization is applied.
            If key ``type=='L2'`` then applies Tikonhov regularization with
            coefficient in key ``alpha``.
          tol (float): tolerance to be used to solve the KL-divergence problem.
          maxit (int): maximum number of iterations
          ders (int): order of derivatives available for the solution of the
            optimization problem.
            0 -> derivative free,
            1 -> gradient,
            2 -> hessian.
          fungrad (bool): whether the distributions :math:`\pi_1,\pi_2` provide the method
            :func:`Distribution.tuple_grad_x_log_pdf` computing the evaluation and the
            gradient in one step. This is used only for ``ders==1``.
          precomp_type (str): whether to precompute univariate Vandermonde matrices 'uni' or
            multivariate Vandermonde matrices 'multi'
          batch_size (:class:`list<list>` [3 or 2] of :class:`int<int>`): the list contains the
            size of the batch to be used for each iteration. A size ``1`` correspond
            to a completely non-vectorized evaluation. A size ``None`` correspond to a
            completely vectorized one.
          nprocs (int): number of processors to be used for function evaluation,
            gradient evaluation and Hessian evaluation. Value ``None`` will determine the
            MPI size automatically (or set to ``nprocs=1`` if MPI is not supported)
          grad_check (bool): whether to use finite difference to check the correctness of
            of the gradient
          hess_check (bool): whether to use finite difference to check the correctenss of
            the Hessian

        Returns:
          log (dict): log informations from the solver

        .. note:: The parameters ``(qtype,qparams)`` and ``(x,w)`` are mutually
          exclusive, but one pair of them is necessary.
        """
        self.logger.debug("minimize_kl_divergence(): Precomputation started")

        (x, w) = ParametricTransportMap.generate_quadrature(
            d1, x, w, qtype, qparams, mpi_pool)
        
        # Distribute objects
        d2_distr = dill.loads( dill.dumps(d2) )
        d2_distr.reset_counters() # Reset counters on copy to avoid couting twice
        mpi_bcast_dmem(d2=d2_distr, mpi_pool=mpi_pool)

        # Set mpi_pool in the object
        if batch_size is None:
            batch_size = [None] * 3
        self.logger.debug("minimize_kl_divergence(): batch sizes: %s" % str(batch_size))

        # Link tm to d2.transport_map
        def link_tm_d2(d2):
            return (d2.transport_map,)
        (tm,) = mpi_map_alloc_dmem(
                link_tm_d2, dmem_key_in_list=['d2'], dmem_arg_in_list=['d2'],
                dmem_val_in_list=[d2], dmem_key_out_list=['tm'],
                mpi_pool=mpi_pool)

        from TransportMaps.Distributions.TransportMapDistributions import \
            PullBackTransportMapDistribution, PushForwardTransportMapDistribution
        if isinstance(d2, PullBackTransportMapDistribution):
            # Init memory
            params2 = {
                'params_pi': params_d2,
                'params_t': {'components': [{} for i in range(self.dim)]} }
            mpi_bcast_dmem(params2=params2, mpi_pool=mpi_pool)
            
            # precomp_minimize_kl_divergence
            bcast_tuple = (['precomp_type'],[precomp_type])
            mpi_map("precomp_minimize_kl_divergence",
                    bcast_tuple=bcast_tuple,
                    dmem_key_in_list=['params2', 'x'],
                    dmem_arg_in_list=['params', 'x'],
                    dmem_val_in_list=[params2, x],
                    obj='tm', obj_val=tm,
                    mpi_pool=mpi_pool, concatenate=False)
        elif isinstance(d2, PushForwardTransportMapDistribution):
            # Init memory
            params2 = { 'params_pi': params_d2,
                        'params_t': {} }
            mpi_bcast_dmem(params2=params2, mpi_pool=mpi_pool)
        else:
            raise AttributeError("Not recognized distribution type")
        # allocate cache
        (cache, ) = mpi_map_alloc_dmem(
            "allocate_cache_minimize_kl_divergence",
            dmem_key_in_list=['x'],
            dmem_arg_in_list=['x'],
            dmem_val_in_list=[x],
            dmem_key_out_list=['cache'],
            obj='tm', obj_val=tm,
            mpi_pool=mpi_pool, concatenate=False)        
        self.logger.debug("minimize_kl_divergence(): Precomputation ended")
        params = {}
        params['nobj'] = 0
        params['nda_obj'] = 0
        params['nda2_obj'] = 0
        params['nda2_obj_dot'] = 0
        params['x'] = x
        params['w'] = w
        params['d1'] = d1
        params['d2'] = d2
        params['params1'] = params_d1
        params['params2'] = params2
        params['cache'] = cache
        params['batch_size'] = batch_size
        params['regularization'] = regularization
        params['grad_check'] = grad_check
        params['hess_check'] = hess_check
        params['hess_assembled'] = False
        params['mpi_pool'] = mpi_pool

        if x0 is None:
            x0 = self.get_default_init_values_minimize_kl_divergence()

        params['objective_cache_coeffs'] = x0 - 1.

        # Callback variables
        self.it_callback = 0
        self.ders_callback = ders
        self.params_callback = params

        # Options for optimizer
        options = {'maxiter': maxit,
                   'disp': False}

        if ders >= 1:
            if fungrad:
                fun = self.minimize_kl_divergence_tuple_grad_a_objective
                jac = True
            else:
                fun = self.minimize_kl_divergence_objective
                jac = self.minimize_kl_divergence_grad_a_objective
        
        # Solve
        self.logger.info("Gradient norm tolerance set to "+str(tol))
        if ders == 0:
            self.logger.info("Starting BFGS without user provided Jacobian")
            options['norm'] = np.inf
            res = sciopt.minimize(
                self.minimize_kl_divergence_objective,
                args=params, x0=x0, method='BFGS', tol=tol,
                options=options, callback=self.minimize_kl_divergence_callback)
        elif ders == 1:
            self.logger.info("Starting BFGS with user provided Jacobian")
            # options['norm'] = np.inf
            options['norm'] = 2
            res = sciopt.minimize(
                fun, args=params, x0=x0, jac=jac, method='BFGS',
                tol=tol, options=options,
                callback=self.minimize_kl_divergence_callback)
        elif ders == 2:
            if hessact:
                self.logger.info("Starting Newton-CG with user provided action of Hessian")
                res = sciopt.minimize(
                    fun, args=params, x0=x0, jac=jac,
                    hessp=self.minimize_kl_divergence_action_hess_a_objective,
                    method='Newton-CG', tol=tol, options=options,
                    callback=self.minimize_kl_divergence_callback)
            else:
                self.logger.info("Starting Newton-CG with user provided Hessian")
                res = sciopt.minimize(
                    fun, args=params, x0=x0, jac=jac,
                    hessp=self.minimize_kl_divergence_action_storage_hess_a_objective,
                    method='Newton-CG', tol=tol, options=options,
                    callback=self.minimize_kl_divergence_callback)

        # Clean up callback stuff
        del self.it_callback
        del self.ders_callback
        del self.params_callback

        # Get d2 from children processes and update counters
        if mpi_pool is not None:
            d2_child_list = mpi_pool.get_dmem('d2')
            d2.update_ncalls_tree( d2_child_list[0][0] )
            for (d2_child,) in d2_child_list:
                d2.update_nevals_tree(d2_child)
                d2.update_teval_tree(d2_child)

        # Log
        log = {}
        log['success'] = res['success']
        log['message'] = res['message']
        log['fval'] = res['fun']
        log['nit'] = res['nit']
        log['n_fun_ev'] = params['nobj']
        if ders >= 1:
            log['n_jac_ev'] = params['nda_obj']
            log['jac'] = res['jac']
        if ders >= 2:
            log['n_hess_ev'] = params['nda2_obj']
            
        # Attach cache to log
        if mpi_pool is None:
            log['cache'] = cache
        else:
            log['cache'] = [ t[0] for t in mpi_pool.get_dmem('cache') ]
            
        # Display stats
        if log['success']:
            self.logger.info("minimize_kl_divergence: Optimization terminated successfully")
        else:
            self.logger.warn("minimize_kl_divergence: Minimization of KL-divergence failed.")
            self.logger.warn("minimize_kl_divergence: Message: %s" % log['message'])
        self.logger.info("minimize_kl_divergence:   Function value: %e" % log['fval'])
        if ders >= 1:
            self.logger.info(
                "minimize_kl_divergence:   Jacobian " + \
                "2-norm: %e " % npla.norm(log['jac'],2) + \
                "inf-norm: %e" % npla.norm(log['jac'],np.inf)
            )
        self.logger.info("minimize_kl_divergence:   Number of iterations:    %6d" % log['nit'])
        self.logger.info("minimize_kl_divergence:   N. function evaluations: %6d" % log['n_fun_ev'])
        if ders >= 1:
            self.logger.info(
                "minimize_kl_divergence:   N. Jacobian evaluations: %6d" % log['n_jac_ev'])
        if ders >= 2:
            self.logger.info(
                "minimize_kl_divergence:   N. Hessian evaluations:  %6d" % log['n_hess_ev'])
            
        # Clear mpi_pool and detach object
        if mpi_pool is not None:
            mpi_pool.clear_dmem()
        
        # Set coefficients
        d2.coeffs = res['x']
        return log

    # def minimize_kl_divergence(self, d1, d2,
    #                            qtype=None, qparams=None,
    #                            x=None, w=None,
    #                            params1=None, params2=None,
    #                            x0=None,
    #                            regularization=None,
    #                            tol=1e-4, maxit=100, ders=2,
    #                            fungrad=False,
    #                            precomp_type='uni',
    #                            batch_size=None,
    #                            nprocs=None,
    #                            grad_check=False, hess_check=False):
    #     r""" [Abstract] Compute: :math:`{\bf a}^* = \arg\min_{\bf a}\mathcal{D}_{KL}\left(\pi_1, \pi_{2,{\bf a}}\right)`

    #     Args:
    #       d1 (Distribution): distribution :math:`\pi_1`
    #       d2 (Distribution): distribution :math:`\pi_2`
    #       qtype (int): quadrature type number provided by :math:`\pi`
    #       qparams (object): inputs necessary to the generation of the selected
    #         quadrature
    #       x (:class:`ndarray<numpy.ndarray>` [:math:`m,d`]): quadrature points
    #       w (:class:`ndarray<numpy.ndarray>` [:math:`m`]): quadrature weights
    #       params1 (dict): parameters for distribution :math:`\pi_1`
    #       params2 (dict): parameters for distribution :math:`\pi_2`
    #       x0 (:class:`ndarray<numpy.ndarray>` [:math:`N`]): coefficients to be used
    #         as initial values for the optimization
    #       regularization (dict): defines the regularization to be used.
    #         If ``None``, no regularization is applied.
    #         If key ``type=='L2'`` then applies Tikonhov regularization with
    #         coefficient in key ``alpha``.
    #       tol (float): tolerance to be used to solve the KL-divergence problem.
    #       maxit (int): maximum number of iterations
    #       ders (int): order of derivatives available for the solution of the
    #         optimization problem.
    #         0 -> derivative free,
    #         1 -> gradient,
    #         2 -> hessian.
    #       fungrad (bool): whether the distributions :math:`\pi_1,\pi_2` provide the method
    #         :func:`Distribution.tuple_grad_x_log_pdf` computing the evaluation and the
    #         gradient in one step. This is used only for ``ders==1``.
    #       precomp_type (str): whether to precompute univariate Vandermonde matrices 'uni' or
    #         multivariate Vandermonde matrices 'multi'
    #       batch_size (:class:`list<list>` [3 or 2] of :class:`int<int>`): the list contains the
    #         size of the batch to be used for each iteration. A size ``1`` correspond
    #         to a completely non-vectorized evaluation. A size ``None`` correspond to a
    #         completely vectorized one.
    #       nprocs (int): number of processors to be used for function evaluation,
    #         gradient evaluation and Hessian evaluation. Value ``None`` will determine the
    #         MPI size automatically (or set to ``nprocs=1`` if MPI is not supported)
    #       grad_check (bool): whether to use finite difference to check the correctness of
    #         of the gradient
    #       hess_check (bool): whether to use finite difference to check the correctenss of
    #         the Hessian

    #     Returns:
    #       log (dict): log informations from the solver

    #     .. note:: The parameters ``(qtype,qparams)`` and ``(x,w)`` are mutually
    #       exclusive, but one pair of them is necessary.
    #     """
    #     raise NotImplementedError("Abstract method.")

    def minimize_kl_divergence_objective(self, a, params):
        r""" Objective function :math:`\mathcal{D}_{KL}\left(\pi_1, \pi_{2,{\bf a}}\right)` for the KL-divergence minimization.

        Args:
          a (:class:`ndarray<numpy.ndarray>` [:math:`N`]): coefficients
          params (dict): dictionary of parameters
        """
        params['nobj'] += 1
        x = params['x']
        w = params['w']
        d1 = params['d1']
        d2 = params['d2']
        params1 = params['params1']
        params2 = params['params2']
        cache = params['cache']
        batch_size = params['batch_size']
        mpi_pool = params['mpi_pool']
        # Update distribution coefficients
        d2.coeffs = a
        bcast_tuple = (['coeffs'],[a])
        mpi_map("_set_coeffs", bcast_tuple=bcast_tuple,
                obj='d2', obj_val=d2,
                mpi_pool=mpi_pool, concatenate=False)
        # Reset cache
        if (params['objective_cache_coeffs'] != self.coeffs).any():
            params['objective_cache_coeffs'] = self.coeffs.copy()
            dmem_key_in_list = ['cache']
            dmem_arg_in_list = ['cache']
            dmem_val_in_list = [cache]
            mpi_map("reset_cache_minimize_kl_divergence",
                    dmem_key_in_list=dmem_key_in_list,
                    dmem_arg_in_list=dmem_arg_in_list,
                    dmem_val_in_list=dmem_val_in_list,
                    obj='tm', obj_val=d2.transport_map,
                    mpi_pool=mpi_pool,
                    concatenate=False)
        # Evaluate KL-divergence
        bcast_tuple = (['d1', 'batch_size', 'd1_entropy'],
                       [None, batch_size[0], False])
        dmem_key_in_list = ['x', 'w', 'd2', 'params1', 'params2', 'cache']
        dmem_arg_in_list = ['x', 'w', 'd2', 'params1', 'params2', 'cache']
        dmem_val_in_list = [x, w, d2, params1, params2, cache]
        reduce_obj = SumChunkReduce(axis=0)
        out = mpi_map(kl_divergence, 
                      bcast_tuple=bcast_tuple,
                      dmem_key_in_list=dmem_key_in_list,
                      dmem_arg_in_list=dmem_arg_in_list,
                      dmem_val_in_list=dmem_val_in_list,
                      reduce_obj=reduce_obj,
                      mpi_pool=mpi_pool)
        if params['regularization'] == None:
            pass
        elif params['regularization']['type'] == 'L2':
            out += params['regularization']['alpha'] * \
                   npla.norm( a - d2.transport_map.get_identity_coeffs() ,2)**2.
        elif params['regularization']['type'] == 'L1':
            # using ||a||_1 regularization (not squared)
            centered_coeffs = a - d2.transport_map.get_identity_coeffs() 
            weighted_a = params['regularization']['alpha']*params['regularization']['l1_weights']*centered_coeffs
            out += npla.norm(weighted_a,1)
            #print(params['regularization']['alpha'] * params['regularization']['l1_weights'])
        # LOGGING
        self.logger.debug("KL Obj. Eval. %d - KL-divergence = %.10e" % (params['nobj'], out))
        # if self.logger.getEffectiveLevel() <= logging.DEBUG:
        #     gx = np.min(d2.transport_map.grad_x(x))
        #     self.logger.debug("KL-evaluation %d - min(grad_x) = %e" % (
        #         params['nobj'], min_gx))
        params['fval'] = out
        return out

    def minimize_kl_divergence_grad_a_objective(self, a, params):
        r""" Gradient of the objective function :math:`\mathcal{D}_{KL}\left(\pi_1, \pi_{2,{\bf a}}\right)` for the KL-divergence minimization.

        Args:
          a (:class:`ndarray<numpy.ndarray>` [:math:`N`]): coefficients
          params (dict): dictionary of parameters
        """
        params['nda_obj'] += 1
        x = params['x']
        w = params['w']
        d1 = params['d1']
        d2 = params['d2']
        params1 = params['params1']
        params2 = params['params2']
        cache = params['cache']
        batch_size = params['batch_size']
        mpi_pool = params['mpi_pool']
        # Update distribution coefficients
        d2.coeffs = a
        bcast_tuple = (['coeffs'],[a])
        mpi_map("_set_coeffs", bcast_tuple=bcast_tuple,
                obj='d2', obj_val=d2,
                mpi_pool=mpi_pool, concatenate=False)
        # Reset cache
        if (params['objective_cache_coeffs'] != self.coeffs).any():
            params['objective_cache_coeffs'] = self.coeffs.copy()
            dmem_key_in_list = ['cache']
            dmem_arg_in_list = ['cache']
            dmem_val_in_list = [cache]
            mpi_map("reset_cache_minimize_kl_divergence",
                    dmem_key_in_list=dmem_key_in_list,
                    dmem_arg_in_list=dmem_arg_in_list,
                    dmem_val_in_list=dmem_val_in_list,
                    obj='tm', obj_val=d2.transport_map,
                    mpi_pool=mpi_pool,
                    concatenate=False)
        # Evaluate grad_a KL-divergence
        bcast_tuple = (['d1', 'batch_size'],
                       [None, batch_size[1]])
        dmem_key_in_list = ['x', 'w', 'd2', 'params1', 'params2', 'cache']
        dmem_arg_in_list = ['x', 'w', 'd2', 'params1', 'params2', 'cache']
        dmem_val_in_list = [x, w, d2, params1, params2, cache]
        reduce_obj = SumChunkReduce(axis=0)
        out = mpi_map(grad_a_kl_divergence, 
                      bcast_tuple=bcast_tuple,
                      dmem_key_in_list=dmem_key_in_list,
                      dmem_arg_in_list=dmem_arg_in_list,
                      dmem_val_in_list=dmem_val_in_list,
                      reduce_obj=reduce_obj,
                      mpi_pool=mpi_pool)
        if params['regularization'] == None:
            pass
        elif params['regularization']['type'] == 'L2':
            out += params['regularization']['alpha'] \
                   * 2. * (a - d2.transport_map.get_identity_coeffs())
        elif params['regularization']['type'] == 'L1':
            alpha_reg = params['regularization']['alpha']*params['regularization']['l1_weights']
            # if only scalar is prescribed, set alpha as vector of equal values
            #if np.isscalar(alpha_reg):
            #    alpha_reg = alpha_reg*np.ones(len(a))
            tol_l1    = params['regularization']['tol_l1']
            centered_coeffs = a - d2.transport_map.get_identity_coeffs()
            for i_a, x_a in enumerate(centered_coeffs):
                if np.abs(x_a) >= tol_l1:
                    out[i_a] += alpha_reg[i_a] * np.sign(x_a)
                elif np.abs(x_a) < tol_l1 and out[i_a] < -1. * alpha_reg[i_a]:
                    out[i_a] += alpha_reg[i_a]
                elif np.abs(x_a) < tol_l1 and out[i_a] > 1. * alpha_reg[i_a]:
                    out[i_a] -= alpha_reg[i_a]
                elif np.abs(x_a) < tol_l1 and np.abs(out[i_a]) <= 1. * alpha_reg[i_a]:
                    out[i_a] = 0.

        if params['grad_check']:
            da = 1e-4
            fdg = FD.fd(self.minimize_kl_divergence_objective, a, da, params)
            maxerr = np.max(np.abs(out - fdg))
            if maxerr > da and self.logger.getEffectiveLevel() <= logging.WARNING:
                self.logger.warning("Grad_a KL-evaluation %d - " % params['nda_obj'] + \
                                    "grad_a check FAIL - " + \
                                    "maxerr=%e (da=%e)" % (maxerr, da))
        if self.logger.getEffectiveLevel() <= logging.DEBUG:
            self.logger.debug("KL Grad_a Obj. Eval. %d - 2-norm = %.5e - inf-norm = %.5e" % (
                params['nda_obj'], npla.norm(out), npla.norm(out, ord=np.inf)))
        # if self.logger.getEffectiveLevel() <= logging.DEBUG:
        #     self.logger.debug("KL-evaluation %d - grad_a KLdiv = \n%s" % (
        #         params['nda_obj'], out))
        params['jac'] = out
        return out

    def minimize_kl_divergence_tuple_grad_a_objective(self, a, params):
        r""" Function evaluation and gradient of the objective :math:`\mathcal{D}_{KL}\left(\pi_1, \pi_{2,{\bf a}}\right)` for the KL-divergence minimization.

        Args:
          a (:class:`ndarray<numpy.ndarray>` [:math:`N`]): coefficients
          params (dict): dictionary of parameters
        """
        params['nobj'] += 1
        params['nda_obj'] += 1
        x = params['x']
        w = params['w']
        d1 = params['d1']
        d2 = params['d2']
        params1 = params['params1']
        params2 = params['params2']
        cache = params['cache']
        batch_size = params['batch_size']
        mpi_pool = params['mpi_pool']
        # Update distribution coefficients
        d2.coeffs = a
        bcast_tuple = (['coeffs'],[a])
        mpi_map("_set_coeffs", bcast_tuple=bcast_tuple,
                obj='d2', obj_val=d2,
                mpi_pool=mpi_pool, concatenate=False)
        # Reset cache
        if (params['objective_cache_coeffs'] != self.coeffs).any():
            params['objective_cache_coeffs'] = self.coeffs.copy()
            dmem_key_in_list = ['cache']
            dmem_arg_in_list = ['cache']
            dmem_val_in_list = [cache]
            mpi_map("reset_cache_minimize_kl_divergence",
                    dmem_key_in_list=dmem_key_in_list,
                    dmem_arg_in_list=dmem_arg_in_list,
                    dmem_val_in_list=dmem_val_in_list,
                    obj='tm', obj_val=d2.transport_map,
                    mpi_pool=mpi_pool,
                    concatenate=False)
        # Evaluate grad_a KL-divergence
        bcast_tuple = (['d1', 'batch_size', 'd1_entropy'],
                       [None, batch_size[1], False])
        dmem_key_in_list = ['x', 'w', 'd2', 'params1', 'params2', 'cache']
        dmem_arg_in_list = ['x', 'w', 'd2', 'params1', 'params2', 'cache']
        dmem_val_in_list = [x, w, d2, params1, params2, cache]
        reduce_obj = TupleSumChunkReduce(axis=0)
        ev, ga = mpi_map(tuple_grad_a_kl_divergence, 
                         bcast_tuple=bcast_tuple,
                         dmem_key_in_list=dmem_key_in_list,
                         dmem_arg_in_list=dmem_arg_in_list,
                         dmem_val_in_list=dmem_val_in_list,
                         reduce_obj=reduce_obj,
                         mpi_pool=mpi_pool)
        if params['regularization'] == None:
            pass
        elif params['regularization']['type'] == 'L2':
            ev += params['regularization']['alpha'] * \
                  npla.norm(a - d2.transport_map.get_identity_coeffs(),2)**2.
            ga += params['regularization']['alpha'] \
                  * 2. * (a - d2.transport_map.get_identity_coeffs())
        if params['grad_check']:
            da = 1e-4
            fdg = FD.fd(self.minimize_kl_divergence_objective, a, da, params)
            maxerr = np.max(np.abs(out - fdg))
            if maxerr > da and self.logger.getEffectiveLevel() <= logging.WARNING:
                self.logger.warning("Grad_a KL-evaluation %d - " % params['nda_obj'] + \
                                    "grad_a check FAIL - " + \
                                    "maxerr=%e (da=%e)" % (maxerr, da))
        # LOGGING
        if self.logger.getEffectiveLevel() <= logging.DEBUG:
            self.logger.debug("KL Obj. Eval. %d - KL-divergence = %.10e" % (params['nobj'], ev))
            self.logger.debug("KL Grad_a Obj. Eval. %d - 2-norm = %.5e - inf-norm = %.5e" % (
                params['nda_obj'], npla.norm(ga), npla.norm(ga, ord=np.inf)))
        # if self.logger.getEffectiveLevel() <= logging.DEBUG:
        #     self.logger.debug("KL-evaluation %d - grad_a KLdiv = \n%s" % (
        #         params['nda_obj'], out))
        params['fval'] = ev    
        params['jac'] = ga
        return ev, ga

    def minimize_kl_divergence_hess_a_objective(self, a, params):
        r""" Hessian of the objective function :math:`\mathcal{D}_{KL}\left(\pi_1, \pi_{2,{\bf a}}\right)` for the KL-divergence minimization.

        Args:
          a (:class:`ndarray<numpy.ndarray>` [:math:`N`]): coefficients
          params (dict): dictionary of parameters
        """
        params['nda2_obj'] += 1
        x = params['x']
        w = params['w']
        d1 = params['d1']
        d2 = params['d2']
        params1 = params['params1']
        params2 = params['params2']
        cache = params['cache']
        batch_size = params['batch_size']
        mpi_pool = params['mpi_pool']
        # Update distribution coefficients
        d2.coeffs = a
        bcast_tuple = (['coeffs'],[a])
        mpi_map("_set_coeffs", bcast_tuple=bcast_tuple,
                obj='d2', obj_val=d2,
                mpi_pool=mpi_pool, concatenate=False)
        # Reset cache
        if (params['objective_cache_coeffs'] != self.coeffs).any():
            params['objective_cache_coeffs'] = self.coeffs.copy()
            dmem_key_in_list = ['cache']
            dmem_arg_in_list = ['cache']
            dmem_val_in_list = [cache]
            mpi_map("reset_cache_minimize_kl_divergence",
                    dmem_key_in_list=dmem_key_in_list,
                    dmem_arg_in_list=dmem_arg_in_list,
                    dmem_val_in_list=dmem_val_in_list,
                    obj='tm', obj_val=d2.transport_map,
                    mpi_pool=mpi_pool,
                    concatenate=False)
        # Evaluate hess_a KL-divergence
        bcast_tuple = (['d1', 'batch_size'],
                       [None, batch_size[2]])
        dmem_key_in_list = ['x', 'w', 'd2', 'params1', 'params2', 'cache']
        dmem_arg_in_list = ['x', 'w', 'd2', 'params1', 'params2', 'cache']
        dmem_val_in_list = [x, w, d2, params1, params2, cache]
        reduce_obj = SumChunkReduce(axis=0)
        out = mpi_map(hess_a_kl_divergence, 
                      bcast_tuple=bcast_tuple,
                      dmem_key_in_list=dmem_key_in_list,
                      dmem_arg_in_list=dmem_arg_in_list,
                      dmem_val_in_list=dmem_val_in_list,
                      reduce_obj=reduce_obj,
                      mpi_pool=mpi_pool)
        if params['regularization'] == None:
            pass
        elif params['regularization']['type'] == 'L2':
            out += np.diag( np.ones(d2.n_coeffs)*2.*params['regularization']['alpha'] )
        if params['hess_check']:
            da = 1e-4
            fdg = FD.fd(self.minimize_kl_divergence_grad_a_objective, a, da, params)
            maxerr = np.max(np.abs(out - fdg))
            if maxerr > da:
                self.logger.warning("Hess_a KL-evaluation %d - " % params['nda2_obj'] + \
                                    "hess_a check FAIL - " + \
                                    "maxerr=%e (da=%e)" % (maxerr, da))
        if self.logger.getEffectiveLevel() <= logging.DEBUG:
            self.logger.debug("KL Hess_a Obj. Eval. %d " % params['nda2_obj'])
        # if self.logger.getEffectiveLevel() <= logging.DEBUG:
        #     import dill
        #     U,S,V = scila.svd(out)
        #     try:
        #         with open('svd.dat', 'rb') as stream:
        #             ll = dill.load(stream)
        #     except IOError:
        #         ll = []
        #     ll.append(S)
        #     with open('svd.dat', 'wb') as stream:
        #         dill.dump(ll, stream)
        return out

    def minimize_kl_divergence_action_hess_a_objective(self, a, da, params):
        r""" Action of the Hessian of the objective function :math:`\mathcal{D}_{KL}\left(\pi_1, \pi_{2,{\bf a}}\right)` on the direction ``v``

        Args:
          a (:class:`ndarray<numpy.ndarray>` [:math:`N`]): coefficients
          da (:class:`ndarray<numpy.ndarray>` [:math:`N`]):
            vector on which to apply the Hessian
          params (dict): dictionary of parameters
        """
        params['nda2_obj'] += 1
        x = params['x']
        w = params['w']
        d1 = params['d1']
        d2 = params['d2']
        params1 = params['params1']
        params2 = params['params2']
        cache = params['cache']
        batch_size = params['batch_size']
        mpi_pool = params['mpi_pool']
        # Update distribution coefficients
        d2.coeffs = a
        bcast_tuple = (['coeffs'],[a])
        mpi_map("_set_coeffs", bcast_tuple=bcast_tuple,
                obj='d2', obj_val=d2,
                mpi_pool=mpi_pool, concatenate=False)
        # Reset cache
        if (params['objective_cache_coeffs'] != self.coeffs).any():
            params['objective_cache_coeffs'] = self.coeffs.copy()
            dmem_key_in_list = ['cache']
            dmem_arg_in_list = ['cache']
            dmem_val_in_list = [cache]
            mpi_map("reset_cache_minimize_kl_divergence",
                    dmem_key_in_list=dmem_key_in_list,
                    dmem_arg_in_list=dmem_arg_in_list,
                    dmem_val_in_list=dmem_val_in_list,
                    obj='tm', obj_val=d2.transport_map,
                    mpi_pool=mpi_pool,
                    concatenate=False)
        # Evaluate hess_a KL-divergence
        bcast_tuple = (['da','d1', 'batch_size'],
                       [da, None, batch_size[2]])
        dmem_key_in_list = ['x', 'w', 'd2', 'params1', 'params2', 'cache']
        dmem_arg_in_list = ['x', 'w', 'd2', 'params1', 'params2', 'cache']
        dmem_val_in_list = [x, w, d2, params1, params2, cache]
        reduce_obj = SumChunkReduce(axis=0)
        out = mpi_map(action_hess_a_kl_divergence, 
                      bcast_tuple=bcast_tuple,
                      dmem_key_in_list=dmem_key_in_list,
                      dmem_arg_in_list=dmem_arg_in_list,
                      dmem_val_in_list=dmem_val_in_list,
                      reduce_obj=reduce_obj,
                      mpi_pool=mpi_pool)
        if params['regularization'] == None:
            pass
        elif params['regularization']['type'] == 'L2':
            out += 2. * params['regularization']['alpha'] * da 
        elif params['regularization']['type'] == 'L1':
            # common to ignore effect of L1 on hessian of regularized objective
            out += 0.
        if self.logger.getEffectiveLevel() <= logging.DEBUG:
            self.logger.debug(
                "KL action Hess_a Obj. Eval. %d" % params['nda2_obj'] + \
                " - 2-norm = %e" % npla.norm(out, 2) + \
                " - inf-norm = %e" % npla.norm(out,np.inf)
            )
        # if self.logger.getEffectiveLevel() <= logging.DEBUG:
        #     import dill
        #     U,S,V = scila.svd(out)
        #     try:
        #         with open('svd.dat', 'rb') as stream:
        #             ll = dill.load(stream)
        #     except IOError:
        #         ll = []
        #     ll.append(S)
        #     with open('svd.dat', 'wb') as stream:
        #         dill.dump(ll, stream)
        return out

    def minimize_kl_divergence_action_storage_hess_a_objective(self, a, v, params):
        r""" Assemble the Hessian :math:`\mathcal{D}_{KL}\left(\pi_1, \pi_{2,{\bf a}}\right)` and compute its action on the vector :math:`v`, for the KL-divergence minimization problem.

        Args:
          a (:class:`ndarray<numpy.ndarray>` [:math:`N`]): coefficients
          v (:class:`ndarray<numpy.ndarray>` [:math:`N`]): vector on which to apply the Hessian
          params (dict): dictionary of parameters
        """
        x = params['x']
        w = params['w']
        d1 = params['d1']
        d2 = params['d2']
        params1 = params['params1']
        params2 = params['params2']
        cache = params['cache']
        batch_size = params['batch_size']
        mpi_pool = params['mpi_pool']
        # Update distribution coefficients
        d2.coeffs = a
        bcast_tuple = (['coeffs'],[a])
        mpi_map("_set_coeffs", bcast_tuple=bcast_tuple,
                obj='d2', obj_val=d2,
                mpi_pool=mpi_pool, concatenate=False)
        # Reset cache
        if (params['objective_cache_coeffs'] != self.coeffs).any():
            params['objective_cache_coeffs'] = self.coeffs.copy()
            # Reset cache
            dmem_key_in_list = ['cache']
            dmem_arg_in_list = ['cache']
            dmem_val_in_list = [cache]
            mpi_map("reset_cache_minimize_kl_divergence",
                    dmem_key_in_list=dmem_key_in_list,
                    dmem_arg_in_list=dmem_arg_in_list,
                    dmem_val_in_list=dmem_val_in_list,
                    obj='tm', obj_val=d2.transport_map,
                    mpi_pool=mpi_pool,
                    concatenate=False)
        # Assemble Hessian
        if not params['hess_assembled']:
            # Assemble
            params['nda2_obj'] += 1
            bcast_tuple = (['d1', 'batch_size'],
                           [None, batch_size[2]])
            dmem_key_in_list = ['x', 'w', 'd2', 'params1', 'params2', 'cache']
            dmem_arg_in_list = ['x', 'w', 'd2', 'params1', 'params2', 'cache']
            dmem_val_in_list = [x, w, d2, params1, params2, cache]
            dmem_key_out_list = ['hess_a_kl_divergence']
            (params['hess_a_kl_divergence'], ) = mpi_map_alloc_dmem(
                storage_hess_a_kl_divergence, 
                bcast_tuple=bcast_tuple, dmem_key_in_list=dmem_key_in_list,
                dmem_arg_in_list=dmem_arg_in_list, dmem_val_in_list=dmem_val_in_list,
                dmem_key_out_list=dmem_key_out_list,
                mpi_pool=mpi_pool, concatenate=False)
            params['hess_assembled'] = True
            if self.logger.getEffectiveLevel() <= logging.DEBUG:
                self.logger.debug("KL Storage Hess_a Obj. Eval. %d " % params['nda2_obj'])
        params['nda2_obj_dot'] += 1
        # Evaluate the action of hess_a KL-divergence
        bcast_tuple = (['v'], [v])
        dmem_key_in_list = ['hess_a_kl_divergence']
        dmem_arg_in_list = ['H']
        dmem_val_in_list = [params['hess_a_kl_divergence']]
        reduce_obj = SumChunkReduce(axis=0)
        out = mpi_map(action_stored_hess_a_kl_divergence,
                      bcast_tuple=bcast_tuple,
                      dmem_key_in_list=dmem_key_in_list,
                      dmem_arg_in_list=dmem_arg_in_list,
                      dmem_val_in_list=dmem_val_in_list,
                      reduce_obj=reduce_obj,
                      mpi_pool=mpi_pool)
        if params['regularization'] == None:
            pass
        elif params['regularization']['type'] == 'L2':
            out += 2.*params['regularization']['alpha'] * v
        # if self.logger.getEffectiveLevel() <= logging.DEBUG:
        #     self.logger.debug("KL Action Hess_a Obj. Eval. %d " % params['nda2_obj_dot'] + \
        #                      "- v^T H v = %.10e" % np.dot(out,v))
        return out

    def minimize_kl_divergence_callback(self, xk):
        self.it_callback += 1
        self.logger.info(
            "Iteration %d - " % self.it_callback + \
            "obj = %.5e - " % self.params_callback['fval'] + \
            "jac 2-norm = %.2e - " % npla.norm(self.params_callback['jac']) + \
            "jac inf-norm = %.2e" % npla.norm(self.params_callback['jac'], ord=np.inf))
        if self.ders_callback == 2:
            self.params_callback['hess_assembled'] = False
        
    @staticmethod
    def from_xml(node):
        raise NotImplementedError("To be implemented")
