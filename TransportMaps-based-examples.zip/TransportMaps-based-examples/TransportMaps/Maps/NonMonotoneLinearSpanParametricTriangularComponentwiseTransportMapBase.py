#
# This file is part of TransportMaps.
#
# TransportMaps is free software: you can redistribute it and/or modify
# it under the terms of the GNU Lesser General Public License as published by
# the Free Software Foundation, either version 3 of the License, or
# (at your option) any later version.
#
# TransportMaps is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU Lesser General Public License for more details.
#
# You should have received a copy of the GNU Lesser General Public License
# along with TransportMaps.  If not, see <http://www.gnu.org/licenses/>.
#
# Transport Maps Library
# Copyright (C) 2015-2018 Massachusetts Institute of Technology
# Uncertainty Quantification group
# Department of Aeronautics and Astronautics
#
# Author: Transport Map Team
# Website: transportmaps.mit.edu
# Support: transportmaps.mit.edu/qa/
#

import logging
import dill
import numpy as np
import numpy.linalg as npla
import scipy.optimize as sciopt

from TransportMaps import \
    required_kwargs, \
    deprecate, \
    mpi_map, mpi_map_alloc_dmem, mpi_bcast_dmem

from .LinearSpanParametricTriangularComponentwiseMapBase import \
    LinearSpanParametricTriangularComponentwiseMap, \
    CommonBasisLinearSpanParametricTriangularComponentwiseMap
from .ParametricTriangularComponentwiseTransportMapBase import \
    ParametricTriangularComponentwiseTransportMap

__all__ = [
    'NonMonotoneParametricTriangularComponentwiseTransportMap',
    'NonMonotoneLinearSpanParametricTriangularComponentwiseTransportMap',
    'NonMonotoneCommonBasisLinearSpanParametricTriangularComponentwiseTransportMap',
    # Deprecated
    'LinearSpanTriangularTransportMap',
    'CommonBasisLinearSpanTriangularTransportMap',
    'MonotonicLinearSpanTriangularTransportMap',
    'MonotonicCommonBasisLinearSpanTriangularTransportMap'
]

nax = np.newaxis

class NonMonotoneParametricTriangularComponentwiseTransportMap(
        ParametricTriangularComponentwiseTransportMap
):
    def minimize_kl_divergence_complete(self, d1, d2,
                                        x=None, w=None,
                                        params_d1=None, params_d2=None,
                                        x0=None,
                                        regularization=None,
                                        tol=1e-4, maxit=100, ders=1,
                                        fungrad=False, hessact=False,
                                        precomp_type='uni',
                                        batch_size=None,
                                        mpi_pool=None,
                                        grad_check=False, hess_check=False):
        r""" Compute: :math:`{\bf a}^* = \arg\min_{\bf a}\mathcal{D}_{KL}\left(\pi_1, \pi_{2,{\bf a}}\right)`

        Args:
          d1 (Distribution): distribution :math:`\pi_1`
          d2 (Distribution): distribution :math:`\pi_2`
          x (:class:`ndarray<numpy.ndarray>` [:math:`m,d`]): quadrature points
          w (:class:`ndarray<numpy.ndarray>` [:math:`m`]): quadrature weights
          params_d1 (dict): parameters for distribution :math:`\pi_1`
          params_d2 (dict): parameters for distribution :math:`\pi_2`
          x0 (:class:`ndarray<numpy.ndarray>` [:math:`N`]): coefficients to be used
            as initial values for the optimization
          regularization (dict): defines the regularization to be used.
            If ``None``, no regularization is applied.
            If key ``type=='L2'`` then applies Tikonhov regularization with
            coefficient in key ``alpha``.
          tol (float): tolerance to be used to solve the KL-divergence problem.
          maxit (int): maximum number of iterations
          ders (int): order of derivatives available for the solution of the
            optimization problem. 0 -> derivative free (SLSQP), 1 -> gradient (SLSQP).
          fungrad (bool): whether the target distribution provides the method
            :func:`Distribution.tuple_grad_x_log_pdf` computing the evaluation and the
            gradient in one step. This is used only for ``ders==1``.
          hessact (bool): this option is disabled for linear span maps (no Hessian used)
          precomp_type (str): whether to precompute univariate Vandermonde matrices 'uni' or
            multivariate Vandermonde matrices 'multi'
          batch_size (:class:`list<list>` [2] of :class:`int<int>`): the list contains the
            size of the batch to be used for each iteration. A size ``1`` correspond
            to a completely non-vectorized evaluation. A size ``None`` correspond to a
            completely vectorized one.
            If the target distribution is a :class:`ProductDistribution`, then
            the optimization problem decouples and
            ``batch_size`` is a list of lists containing the batch sizes to be
            used for each component of the map.
          mpi_pool (:class:`mpi_map.MPI_Pool` or :class:`list<list>` of ``mpi_pool``):
            pool of processes to be used, ``None`` stands for one process.
            If the target distribution is a :class:`ProductDistribution`, then
            the minimization problem decouples and ``mpi_pool`` is a list containing
            ``mpi_pool``s for each component of the map.
          grad_check (bool): whether to use finite difference to check the correctness of
            of the gradient
          hess_check (bool): whether to use finite difference to check the correctenss of
            the Hessian

        Returns:
          log (dict): log informations from the solver

        .. note:: The parameters ``(qtype,qparams)`` and ``(x,w)`` are mutually
          exclusive, but one pair of them is necessary.
        """
        if ders < 0:
            self.logger.warning("Value for ders too low (%d). Set to 0." % ders)
            ders = 0
        if ders > 1:
            self.logger.warning("Value for ders too high (%d). Set to 1." % ders)
            ders = 1
        
        self.logger.debug("minimize_kl_divergence(): Precomputation started")

        if batch_size is None:
            batch_size = [None] * 2

        # Distribute objects
        d2_distr = dill.loads( dill.dumps(d2) )
        d2_distr.reset_counters() # Reset counters on copy to avoid couting twice
        mpi_bcast_dmem(d2=d2_distr, mpi_pool=mpi_pool)
        # Link tm to d2.transport_map
        def link_tm_d2(d2):
            return (d2.transport_map,)
        (tm,) = mpi_map_alloc_dmem(
            link_tm_d2, dmem_key_in_list=['d2'], dmem_arg_in_list=['d2'],
            dmem_val_in_list=[d2], dmem_key_out_list=['tm'],
            mpi_pool=mpi_pool)

        from TransportMaps.Distributions.TransportMapDistributions import \
            PullBackTransportMapDistribution, PushForwardTransportMapDistribution
        if isinstance(d2, PullBackTransportMapDistribution):
            # Init memory
            params2 = {
                'params_pi': params_d2,
                'params_t': {'components': [{} for i in range(self.dim)]} }
            mpi_bcast_dmem(params2=params2, mpi_pool=mpi_pool)
            
            # precomp_minimize_kl_divergence
            bcast_tuple = (['precomp_type'],[precomp_type])
            mpi_map("precomp_minimize_kl_divergence",
                    bcast_tuple=bcast_tuple,
                    dmem_key_in_list=['params2', 'x'],
                    dmem_arg_in_list=['params', 'x'],
                    dmem_val_in_list=[params2, x],
                    obj='tm', obj_val=tm,
                    mpi_pool=mpi_pool, concatenate=False)
            # allocate_cache_minimize_kl_divergence
            (cache, ) = mpi_map_alloc_dmem(
                "allocate_cache_minimize_kl_divergence",
                dmem_key_in_list=['x'],
                dmem_arg_in_list=['x'],
                dmem_val_in_list=[x],
                dmem_key_out_list=['cache'],
                obj='tm', obj_val=tm,
                mpi_pool=mpi_pool, concatenate=False)
        elif isinstance(d2, PushForwardTransportMapDistribution):
            # Init memory
            params2 = { 'params_pi': params_d2,
                        'params_t': {} }
            mpi_bcast_dmem(params2=params2, mpi_pool=mpi_pool)
            # allocate cache
            (cache, ) = mpi_map_alloc_dmem(
                "allocate_cache_minimize_kl_divergence",
                dmem_key_in_list=['x'],
                dmem_arg_in_list=['x'],
                dmem_val_in_list=[x],
                dmem_key_out_list=['cache'],
                obj='tm', obj_val=tm,
                mpi_pool=mpi_pool, concatenate=False)
        else:
            raise AttributeError("Not recognized distribution type")
        # Append the slices indices
        if self.logger.getEffectiveLevel() <= logging.DEBUG:
            self.logger.debug("minimize_kl_divergence(): Precomputation ended")
        params = {}
        params['nobj'] = 0
        params['nda_obj'] = 0
        params['nda2_obj'] = 0
        params['nda2_obj_dot'] = 0
        params['x'] = x
        params['w'] = w
        params['d1'] = d1
        params['d2'] = d2
        params['params1'] = params_d1
        params['params2'] = params2
        params['cache'] = cache
        params['batch_size'] = batch_size
        params['regularization'] = regularization
        params['grad_check'] = grad_check
        params['hess_check'] = hess_check
        params['mpi_pool'] = mpi_pool

        # Link params_t on the first level of params
        # (this is needed for the MPI implementation of the constraints)
        def link_params_t(params):
            return (params['params_t'],)
        (params['params_t'],) = mpi_map_alloc_dmem(
            link_params_t,
            dmem_key_in_list = ['params2'],
            dmem_arg_in_list = ['params'],
            dmem_val_in_list = [params2],
            dmem_key_out_list = ['params_t'],
            mpi_pool=mpi_pool)

        cons = ({'type': 'ineq',
                 'fun': self.minimize_kl_divergence_constraints,
                 'jac': self.minimize_kl_divergence_da_constraints,
                 'args': (params,)})

        if x0 is None:
            x0 = self.get_default_init_values_minimize_kl_divergence()
            
        params['objective_cache_coeffs'] = x0 - 1.

        # Callback variables
        self.it_callback = 0
        self.ders_callback = ders
        self.params_callback = params

        # Options for optimizer
        options = {'maxiter': maxit,
                   'disp': False}

        # Solve
        if ders == 0:
            res = sciopt.minimize(self.minimize_kl_divergence_objective,
                                  args=params,
                                  x0=x0,
                                  constraints=cons,
                                  method='SLSQP',
                                  tol=tol, 
                                  options=options,
                                  callback=self.minimize_kl_divergence_callback)
        elif ders == 1:
            if fungrad:
                res = sciopt.minimize(self.minimize_kl_divergence_tuple_grad_a_objective,
                                      args=params, x0=x0,
                                      jac=True,
                                      constraints=cons,
                                      method='SLSQP',
                                      tol=tol, 
                                      options=options,
                                      callback=self.minimize_kl_divergence_callback)
            else:
                res = sciopt.minimize(self.minimize_kl_divergence_objective, args=params,
                                      x0=x0,
                                      jac=self.minimize_kl_divergence_grad_a_objective,
                                      constraints=cons,
                                      method='SLSQP',
                                      tol=tol, 
                                      options=options,
                                      callback=self.minimize_kl_divergence_callback)

        # Clean up callback stuff
        del self.it_callback
        del self.ders_callback
        del self.params_callback

        # Get d2 from children processes and update counters
        if mpi_pool is not None:
            d2_child_list = mpi_pool.get_dmem('d2')
            d2.update_ncalls_tree( d2_child_list[0][0] )
            for (d2_child,) in d2_child_list:
                d2.update_nevals_tree(d2_child)
                d2.update_teval_tree(d2_child)

        # Log
        log = {}
        log['success'] = res['success']
        log['message'] = res['message']
        log['fval'] = res['fun']
        log['nit'] = res['nit']
        log['n_fun_ev'] = params['nobj']
        if ders >= 1:
            log['n_jac_ev'] = params['nda_obj']
            log['jac'] = res['jac']

        # Attach cache to log
        if mpi_pool is None:
            log['cache'] = cache
        else:
            log['cache'] = mpi_pool.get_dmem('cache')
        
        # Display stats
        if log['success']:
            self.logger.info("minimize_kl_divergence: Optimization terminated successfully")
        else:
            self.logger.warn("minimize_kl_divergence: Minimization of KL-divergence failed.")
            self.logger.warn("minimize_kl_divergence: Message: %s" % log['message'])
        self.logger.info("minimize_kl_divergence:   Function value:          %6f" % log['fval'])
        if ders >= 1:
            self.logger.info("minimize_kl_divergence:   Norm of the Jacobian:    %6f" % npla.norm(log['jac']))
        self.logger.info("minimize_kl_divergence:   Number of iterations:    %6d" % log['nit'])
        self.logger.info("minimize_kl_divergence:   N. function evaluations: %6d" % log['n_fun_ev'])
        if ders >= 1:
            self.logger.info("minimize_kl_divergence:   N. Jacobian evaluations: %6d" % log['n_jac_ev'])

        # Clear mpi_pool and detach object
        if mpi_pool is not None:
            mpi_pool.clear_dmem()
            
        # Set coefficients
        d2.coeffs = res['x'] 
        return log

    def minimize_kl_divergence_constraints(self, a, params):
        mpi_pool = params['mpi_pool']
        # Update distribution coefficients
        bcast_tuple = (['coeffs'],[a])
        mpi_map("_set_coeffs", bcast_tuple=bcast_tuple,
                obj='tm', obj_val=self,
                mpi_pool=mpi_pool, concatenate=False)
        # Evaluate
        x = params['x']
        dmem_key_in_list = ['params_t', 'x']
        dmem_arg_in_list = ['precomp', 'x']
        dmem_val_in_list = [ params['params_t'], x ]
        out = mpi_map("partial_xd", 
                      dmem_key_in_list=dmem_key_in_list,
                      dmem_arg_in_list=dmem_arg_in_list,
                      dmem_val_in_list=dmem_val_in_list,
                      obj='tm', obj_val=self,
                      mpi_pool=mpi_pool)
        return out.reshape( out.shape[0] * out.shape[1] )

    def minimize_kl_divergence_da_constraints(self, a, params):
        mpi_pool = params['mpi_pool']
        # Update distribution coefficients
        bcast_tuple = (['coeffs'],[a])
        mpi_map("_set_coeffs", bcast_tuple=bcast_tuple,
                obj='tm', obj_val=self,
                mpi_pool=mpi_pool, concatenate=False)
        # Evaluate
        x = params['x']
        dmem_key_in_list = ['params_t', 'x']
        dmem_arg_in_list = ['precomp', 'x']
        dmem_val_in_list = [ params['params_t'], x ]
        out = mpi_map("grad_a_partial_xd", 
                      dmem_key_in_list=dmem_key_in_list,
                      dmem_arg_in_list=dmem_arg_in_list,
                      dmem_val_in_list=dmem_val_in_list,
                      obj='tm', obj_val=self,
                      mpi_pool=mpi_pool)
        return out.reshape( (out.shape[0]*out.shape[1], self.n_coeffs) )

class NonMonotoneLinearSpanParametricTriangularComponentwiseTransportMap(
        LinearSpanParametricTriangularComponentwiseMap,
        NonMonotoneParametricTriangularComponentwiseTransportMap
):
    r""" :class:`LinearSpanParametricTriangularComponentwiseMap` which allows for kl-minimization by enforcing pointwise constraints
    """
    @required_kwargs('active_vars', 'approx_list')
    def __init__(self, **kwargs):
        r"""
        Kwargs:
          active_vars (:class:`list<list>` [:math:`d`] of :class:`list<list>`): for
            each dimension lists the active variables.
          approx_list (:class:`list<list>` [:math:`d`] of :class:`LinearSpanTensorizedParametricFunctional<TransportMaps.Maps.Functionals.LinearSpanTensorizedParametricFunctional`):
            list of parametric functionals for each dimension
          full_basis_list (:class:`list` of :class:`list`): list of basis for each input
            of each component for a full triangular map
            (this is needed for some adaptivity algorithm)
        """
        super(NonMonotoneLinearSpanParametricTriangularComponentwiseTransportMap,
              self).__init__(**kwargs)

    def get_default_init_values_minimize_kl_divergence(self):
        return self.get_identity_coeffs()

class NonMonotoneCommonBasisLinearSpanParametricTriangularComponentwiseTransportMap(
        CommonBasisLinearSpanParametricTriangularComponentwiseMap,
        NonMonotoneParametricTriangularComponentwiseTransportMap
):
    r""" :class:`CommonBasisLinearSpanParametricTriangularComponentwiseMap` which allows for kl-minimization by enforcing pointwise constraints
    """
    @required_kwargs('active_vars', 'approx_list')
    def __init__(self, **kwargs):
        r"""
        Kwargs:
          active_vars (:class:`list<list>` [:math:`d`] of :class:`list<list>`): for
            each dimension lists the active variables.
          approx_list (:class:`list<list>` [:math:`d`] of :class:`LinearSpanTensorizedParametricFunctional<TransportMaps.Maps.Functionals.LinearSpanTensorizedParametricFunctional`):
            list of parametric functionals for each dimension
          full_basis_list (:class:`list` of :class:`list`): list of basis for each input
            of each component for a full triangular map
            (this is needed for some adaptivity algorithm)
        """
        super(NonMonotoneCommonBasisLinearSpanParametricTriangularComponentwiseTransportMap,
              self).__init__(**kwargs)

    def get_default_init_values_minimize_kl_divergence(self):
        return self.get_identity_coeffs()

##############
# DEPRECATED #
##############
    
class MonotonicLinearSpanTriangularTransportMap(
        NonMonotoneLinearSpanParametricTriangularComponentwiseTransportMap
):
    @deprecate(
        'MonotonicLinearSpanTriangularTransportMap',
        '3.0',
        'Use Maps.NonMonotoneLinearSpanParametricTriangularComponentwiseTransportMap instead.'
    )
    def __init__(self, active_vars, approx_list):
        super(MonotonicLinearSpanTriangularTransportMap, self).__init__(
            active_vars=active_vars,
            approx_list=approx_list
        )

class MonotonicCommonBasisLinearSpanTriangularTransportMap(
        NonMonotoneCommonBasisLinearSpanParametricTriangularComponentwiseTransportMap
):
    @deprecate(
        'MonotonicCommonBasisLinearSpanTriangularTransportMap',
        '3.0',
        'Use Maps.NonMonotoneCommonBasisLinearSpanParametricTriangularComponentwiseTransportMap instead.'
    )
    def __init__(self, active_vars, approx_list):
        super(MonotonicCommonBasisLinearSpanTriangularTransportMap,
              self).__init__(
            active_vars=active_vars,
            approx_list=approx_list
        )

class LinearSpanTriangularTransportMap(
        NonMonotoneLinearSpanParametricTriangularComponentwiseTransportMap
):
    @deprecate(
        'LinearSpanTriangularTransportMap',
        '3.0',
        'Use Maps.NonMonotoneLinearSpanParametricTriangularComponentwiseTransportMap instead.'
    )
    def __init__(self, active_vars, approx_list):
        super(LinearSpanTriangularTransportMap, self).__init__(
            active_vars=active_vars,
            approx_list=approx_list
        )

class CommonBasisLinearSpanTriangularTransportMap(
        NonMonotoneCommonBasisLinearSpanParametricTriangularComponentwiseTransportMap
):
    @deprecate(
        'CommonBasisLinearSpanTriangularTransportMap',
        '3.0',
        'Use Maps.NonMonotoneCommonBasisLinearSpanParametricTriangularComponentwiseTransportMap instead.'
    )
    def __init__(self, active_vars, approx_list):
        super(CommonBasisLinearSpanTriangularTransportMap, self).__init__(
            active_vars=active_vars,
            approx_list=approx_list
        )
