#
# This file is part of TransportMaps.
#
# TransportMaps is free software: you can redistribute it and/or modify
# it under the terms of the GNU Lesser General Public License as published by
# the Free Software Foundation, either version 3 of the License, or
# (at your option) any later version.
#
# TransportMaps is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU Lesser General Public License for more details.
#
# You should have received a copy of the GNU Lesser General Public License
# along with TransportMaps.  If not, see <http://www.gnu.org/licenses/>.
#
# Transport Maps Library
# Copyright (C) 2015-2018 Massachusetts Institute of Technology
# Uncertainty Quantification group
# Department of Aeronautics and Astronautics
#
# Authors: Transport Map Team
# Website: transportmaps.mit.edu
# Support: transportmaps.mit.edu/qa/
#

import logging
import numpy as np
import numpy.linalg as npla
import scipy.optimize as sciopt

from TransportMaps.Misc import mpi_map, mpi_map_alloc_dmem, mpi_bcast_dmem, \
    SumChunkReduce, deprecate

from .LinearSpanTensorizedParametricFunctionalBase import LinearSpanTensorizedParametricFunctional
from .ParametricMonotoneFunctionalBase import ParametricMonotoneFunctional

__all__ = [
    'PointwiseMonotoneLinearSpanTensorizedParametricFunctional',
    # Deprecated
    'MonotonicLinearSpanApproximation'
]

nax = np.newaxis

class PointwiseMonotoneLinearSpanTensorizedParametricFunctional(
        LinearSpanTensorizedParametricFunctional,
        ParametricMonotoneFunctional
):
    r""" Approximation of the type :math:`f \approx f_{\bf a} = \sum_{{\bf i} \in \mathcal{I}} {\bf a}_{\bf i} \Phi_{\bf i}`, monotonic in :math:`x_d`

    Args:
      basis_list (list): list of :math:`d`
        :class:`OrthogonalBasis<SpectralToolbox.OrthogonalBasis>`
      spantype (str): Span type. 'total' total order, 'full' full order,
        'midx' multi-indeces specified
      order_list (:class:`list<list>` of :class:`int<int>`): list of 
        orders :math:`\{N_i\}_{i=0}^d`
      multi_idxs (list): list of tuples containing the active multi-indices
    """
    def precomp_regression(self, x, precomp=None, *args, **kwargs):
        r""" Precompute necessary structures for the speed up of :func:`regression`

        Args:
          x (:class:`ndarray<numpy.ndarray>` [:math:`m,d`]): evaluation points
          precomp (dict): dictionary to be updated

        Returns:
           (:class:`dict<dict>`) -- dictionary of necessary strucutres
        """
        if precomp is None:
            precomp = {}
        precomp.update( self.precomp_evaluate(x) )
        precomp.update( self.precomp_partial_xd(x) )
        return precomp

    def get_identity_coeffs(self):
        coeffs = np.zeros(self.n_coeffs)
        idx = next( i for i, idx in enumerate(self.multi_idxs)
                    if idx == tuple([0]*(self.dim_in-1) + [1]) )
        coeffs[idx] = 1.
        return coeffs

    def regression(self, f, fparams=None, d=None, qtype=None, qparams=None,
                   x=None, w=None, x0=None,
                   regularization=None, tol=1e-4, maxit=100,
                   batch_size=(None,None), mpi_pool=None, import_set=set()):
        r""" Compute :math:`{\bf a}^* = \arg\min_{\bf a} \Vert f - f_{\bf a} \Vert_{\pi}`.

        Args:
          f (:class:`Function` or :class:`ndarray<numpy.ndarray>` [:math:`m`]): function
            :math:`f` or its functions values
          d (Distribution): distribution :math:`\pi`
          fparams (dict): parameters for function :math:`f`
          qtype (int): quadrature type to be used for the approximation of
            :math:`\mathbb{E}_{\pi}`
          qparams (object): parameters necessary for the construction of the
            quadrature
          x (:class:`ndarray<numpy.ndarray>` [:math:`m,d`]): quadrature points
            used for the approximation of :math:`\mathbb{E}_{\pi}`
          w (:class:`ndarray<numpy.ndarray>` [:math:`m`]): quadrature weights
            used for the approximation of :math:`\mathbb{E}_{\pi}`
          x0 (:class:`ndarray<numpy.ndarray>` [:math:`N`]): coefficients to be used
            as initial values for the optimization
          regularization (dict): defines the regularization to be used.
            If ``None``, no regularization is applied.
            If key ``type=='L2'`` then applies Tikonhov regularization with
            coefficient in key ``alpha``.
          tol (float): tolerance to be used to solve the regression problem.
          maxit (int): maximum number of iterations
          batch_size (:class:`list<list>` [2] of :class:`int<int>`): the list contains the
            size of the batch to be used for each iteration. A size ``1`` correspond
            to a completely non-vectorized evaluation. A size ``None`` correspond to a
            completely vectorized one.
          mpi_pool (:class:`mpi_map.MPI_Pool`): pool of processes to be used
          import_set (set): list of couples ``(module_name,as_field)`` to be imported
            as ``import module_name as as_field`` (for MPI purposes)

        Returns:
          (:class:`tuple<tuple>`(:class:`ndarray<numpy.ndarray>` [:math:`N`],
          :class:`list<list>`)) -- containing the :math:`N` coefficients and
          log information from the optimizer.

        .. seealso:: :func:`TransportMaps.TriangularTransportMap.regression`

        .. note:: the resulting coefficients :math:`{\bf a}` are automatically
           set at the end of the optimization. Use :func:`coeffs` in order
           to retrieve them.
        .. note:: The parameters ``(qtype,qparams)`` and ``(x,w)`` are mutually
          exclusive, but one pair of them is necessary.
        """
        if (x is None) and (w is None):
            (x,w) = d.quadrature(qtype, qparams)
        params = {}
        params['x'] = x
        params['w'] = w
        params['regularization'] = regularization
        params['batch_size'] = batch_size
        params['mpi_pool'] = mpi_pool
        cons = ({'type': 'ineq',
                 'fun': self.regression_constraints,
                 'jac': self.regression_grad_a_constraints,
                 'args': (params,)})
        options = {'maxiter': maxit,
                   'disp': False}
        if x0 is None:
            x0 = self.get_default_init_values_regression()
        params['nobj'] = 0
        params['nda_obj'] = 0
        if self.logger.getEffectiveLevel() <= logging.DEBUG:
            self.logger.debug("regression(): Precomputation started")
        # Prepare parameters
        if isinstance(f, np.ndarray):
            params['fvals'] = f
        else:
            scatter_tuple = (['x'], [x])
            bcast_tuple = (['precomp'], [fparams])
            params['fvals'] = mpi_map("evaluate", scatter_tuple=scatter_tuple,
                                      bcast_tuple=bcast_tuple,
                                      obj=f, mpi_pool=mpi_pool)
        # Init precomputation memory
        params['params1'] = {}
        mpi_bcast_dmem(params1=params['params1'], f1=self, mpi_pool=mpi_pool)
        
        # Precompute
        scatter_tuple = (['x'], [x])
        mpi_map("precomp_regression", scatter_tuple=scatter_tuple,
                dmem_key_in_list=['params1'],
                dmem_arg_in_list=['precomp'],
                dmem_val_in_list=[params['params1']],
                obj='f1', obj_val=self,
                mpi_pool=mpi_pool,
                 concatenate=False)
        if self.logger.getEffectiveLevel() <= logging.DEBUG:
            self.logger.debug("regression(): Precomputation ended")
        # Minimize
        res = sciopt.minimize(self.regression_objective, x0, args=params, \
                              jac=self.regression_grad_a_objective,
                              constraints=cons, \
                              method='SLSQP', options=options, tol=tol)
        if not res['success']:
            self.logger.warn("Regression failure: " + res['message'])
        coeffs = res['x']
        self.coeffs = coeffs
        return (coeffs, res)
        
    def regression_constraints(self, a, params):
        # Update coefficients
        bcast_tuple = (['coeffs'], [a])
        mpi_pool = params['mpi_pool']
        mpi_map("_set_coeffs", bcast_tuple=bcast_tuple,
                obj='f1', obj_val=self,
                mpi_pool=mpi_pool, concatenate=False)
        # Evaluate
        x = params['x']
        scatter_tuple = (['x'], [x])
        dmem_key_in_list = ['params1']
        dmem_arg_in_list=['precomp']
        dmem_val_in_list = [params['params1']]
        out = mpi_map("partial_xd", scatter_tuple=scatter_tuple,
                      dmem_key_in_list=dmem_key_in_list,
                      dmem_arg_in_list=dmem_arg_in_list,
                      dmem_val_in_list=dmem_val_in_list,
                      obj='f1', obj_val=self, mpi_pool=mpi_pool)
        return out[:,0]

    def regression_grad_a_constraints(self, a, params):
        mpi_pool = params['mpi_pool']
        # Update coefficients
        bcast_tuple = (['coeffs'], [a])
        mpi_map("_set_coeffs", bcast_tuple=bcast_tuple,
                obj='f1', obj_val=self,
                mpi_pool=mpi_pool, concatenate=False)
        # Evaluate
        x = params['x']
        scatter_tuple = (['x'], [x])
        dmem_key_in_list = ['params1']
        dmem_arg_in_list=['precomp']
        dmem_val_in_list = [params['params1']]
        out = mpi_map("grad_a_partial_xd", scatter_tuple=scatter_tuple,
                      dmem_key_in_list=dmem_key_in_list,
                      dmem_arg_in_list=dmem_arg_in_list,
                      dmem_val_in_list=dmem_val_in_list,
                      obj='f1', obj_val=self, mpi_pool=mpi_pool)
        return out[:,0,:]

    def minimize_kl_divergence_component(self,
                                         f, x, w,
                                         x0=None,
                                         regularization=None,
                                         tol=1e-4, maxit=100, ders=2,
                                         fungrad=False, 
                                         precomp_type='uni',
                                         batch_size=None,
                                         cache_level=1,
                                         mpi_pool=None):
        r""" Compute :math:`{\bf a}^\star = \arg\min_{\bf a}-\sum_{i=0}^m \log\pi\circ T_k(x_i) + \log\partial_{x_k}T_k(x_i) = \arg\min_{\bf a}-\sum_{i=0}^m f(x_i)`

        Args:
          f (ProductDistributionParametricPullbackComponentFunction): function :math:`f` 
          x (:class:`ndarray<numpy.ndarray>` [:math:`m,d`]): quadrature points
          w (:class:`ndarray<numpy.ndarray>` [:math:`m`]): quadrature weights
          x0 (:class:`ndarray<numpy.ndarray>` [:math:`N`]): coefficients to be used
            as initial values for the optimization
          regularization (dict): defines the regularization to be used.
            If ``None``, no regularization is applied.
            If key ``type=='L2'`` then applies Tikonhov regularization with
            coefficient in key ``alpha``.
          tol (float): tolerance to be used to solve the KL-divergence problem.
          maxit (int): maximum number of iterations
          ders (int): order of derivatives available for the solution of the
            optimization problem. 0 -> derivative free, 1 -> gradient, 2 -> hessian.
          fungrad (bool): whether the distributions :math:`\pi_1,\pi_2` provide the method
            :func:`Distribution.tuple_grad_x_log_pdf` computing the evaluation and the
            gradient in one step. This is used only for ``ders==1``.
          precomp_type (str): whether to precompute univariate Vandermonde matrices 'uni' or
            multivariate Vandermonde matrices 'multi'
          batch_size (:class:`list<list>` [3 or 2] of :class:`int<int>` or :class:`list<list>` of ``batch_size``):
            the list contains the
            size of the batch to be used for each iteration. A size ``1`` correspond
            to a completely non-vectorized evaluation. A size ``None`` correspond to a
            completely vectorized one.
            If the target distribution is a :class:`ProductDistribution`, then
            the optimization problem decouples and
            ``batch_size`` is a list of lists containing the batch sizes to be
            used for each component of the map.
          cache_level (int): use high-level caching during the optimization, storing the
            function evaluation ``0``, and the gradient evaluation ``1`` or
            nothing ``-1``
          mpi_pool (:class:`mpi_map.MPI_Pool` or :class:`list<list>` of ``mpi_pool``):
            pool of processes to be used, ``None`` stands for one process.
            If the target distribution is a :class:`ProductDistribution`, then
            the minimization problem decouples and ``mpi_pool`` is a list containing
            ``mpi_pool``s for each component of the map.
        """
        self.logger.debug("minimize_kl_divergence_component(): Precomputation started")

        if batch_size is None:
            batch_size = [None] * 3
        # Distribute objects
        mpi_bcast_dmem(f=f, mpi_pool=mpi_pool)
        # Link tm_comp to f.tmap_component
        def link_tmcmp(f):
            return (f.tmap_component,)
        (tm_comp,) = mpi_map_alloc_dmem(
            link_tmcmp, dmem_key_in_list=['f'], dmem_arg_in_list=['f'],
            dmem_val_in_list=[f], dmem_key_out_list=['tm_comp'],
            mpi_pool=mpi_pool)
        # Init memory
        paramsf = {'params_pi': None,
                   'params_t': {} }
        mpi_bcast_dmem(paramsf=paramsf, mpi_pool=mpi_pool)
        dmem_key_in_list = ['paramsf']
        dmem_arg_in_list = ['params']
        dmem_val_in_list = [paramsf]
        # precomp_minimize_kl_divergence_component
        scatter_tuple = (['x'],[x])
        bcast_tuple = (['precomp_type'],[precomp_type])
        mpi_map("precomp_minimize_kl_divergence_component",
                scatter_tuple=scatter_tuple,
                bcast_tuple=bcast_tuple,
                dmem_key_in_list=dmem_key_in_list,
                dmem_arg_in_list=dmem_arg_in_list,
                dmem_val_in_list=dmem_val_in_list,
                obj='tm_comp', obj_val=tm_comp,
                mpi_pool=mpi_pool, concatenate=False)
        # allocate_cache_minimize_kl_divergence_component
        scatter_tuple = (['x'],[x])
        (cache, ) = mpi_map_alloc_dmem(
            "allocate_cache_minimize_kl_divergence_component",
            scatter_tuple=scatter_tuple,
            dmem_key_out_list=['cache'],
            obj='tm_comp', obj_val=tm_comp,
            mpi_pool=mpi_pool, concatenate=False)
        self.logger.debug("minimize_kl_divergence(): Precomputation ended")

        params = {}
        params['nobj'] = 0
        params['nda_obj'] = 0
        params['x'] = x
        params['w'] = w
        params['f'] = f
        params['paramsf'] = paramsf
        params['batch_size'] = batch_size
        params['cache'] = cache
        params['regularization'] = regularization
        params['mpi_pool'] = mpi_pool

        if x0 is None:
            x0 = self.get_default_init_values_minimize_kl_divergence_component()

        # Link params_t on the first level of params
        # (this is needed for the MPI implementation of the constraints)
        def link_params_t(params):
            return (params['params_t'],)
        (params['params_t'],) = mpi_map_alloc_dmem(
            link_params_t,
            dmem_key_in_list = ['paramsf'],
            dmem_arg_in_list = ['params'],
            dmem_val_in_list = [paramsf],
            dmem_key_out_list = ['params_t'],
            mpi_pool=mpi_pool)

        cons = ({'type': 'ineq',
                 'fun': self.minimize_kl_divergence_component_constraints,
                 'jac': self.minimize_kl_divergence_component_da_constraints,
                 'args': (params,)})

        if cache_level >= 0:
            params['objective_cache_coeffs'] = x0 - 1.

        # Callback variables
        self.it_callback = 0
        self.ders_callback = ders
        self.params_callback = params

        # Options for optimizer
        options = {'maxiter': maxit,
                   'disp': False}

        # Solve
        if ders == 0:
            res = sciopt.minimize(self.minimize_kl_divergence_component_objective,
                                  args=params,
                                  x0=x0,
                                  constraints=cons,
                                  method='SLSQP',
                                  tol=tol, 
                                  options=options,
                                  callback=self.minimize_kl_divergence_component_callback)
        elif ders == 1:
            if fungrad:
                raise NotImplementedError("Option fungrad not implemented for maps from samples")
                # res = sciopt.minimize(self.minimize_kl_divergence_tuple_grad_a_objective,
                #                       args=params, x0=x0,
                #                       jac=True,
                #                       constraints=cons,
                #                       method='SLSQP',
                #                       tol=tol, 
                #                       options=options,
                #                       callback=self.minimize_kl_divergence_callback)
            else:
                res = sciopt.minimize(
                    self.minimize_kl_divergence_component_objective, args=params,
                    x0=x0,
                    jac=self.minimize_kl_divergence_component_grad_a_objective,
                    constraints=cons,
                    method='SLSQP',
                    tol=tol, 
                    options=options,
                    callback=self.minimize_kl_divergence_component_callback)
        else:
            raise NotImplementedError(
                "ders is %d, but must be ders=[0,1] " % ders + \
                "with MonotonicLinearSpanApproximation."
            )

        # Clean up callback stuff
        del self.it_callback
        del self.ders_callback
        del self.params_callback

        # Log
        log = {}
        log['success'] = res['success']
        log['message'] = res['message']
        log['fval'] = res['fun']
        log['nit'] = res['nit']
        log['n_fun_ev'] = params['nobj']
        if ders >= 1:
            log['n_jac_ev'] = params['nda_obj']
            log['jac'] = res['jac']
        # Display stats
        if log['success']:
            self.logger.info("Optimization terminated successfully")
        else:
            self.logger.info("Optimization failed.")
            self.logger.info("Message: %s" % log['message'])
        self.logger.info("  Function value:          %6f" % log['fval'])
        if ders >= 1:
            self.logger.info("  Norm of the Jacobian:    %6f" % npla.norm(log['jac']))
        self.logger.info("  Number of iterations:    %6d" % log['nit'])
        self.logger.info("  N. function evaluations: %6d" % log['n_fun_ev'])
        if ders >= 1:
            self.logger.info("  N. Jacobian evaluations: %6d" % log['n_jac_ev'])

        # Set coefficients
        self.coeffs = res['x']
        return log

    def minimize_kl_divergence_component_constraints(self, a, params):
        mpi_pool = params['mpi_pool']
        # Update coefficients
        bcast_tuple = (['coeffs'],[a])
        mpi_map("_set_coeffs", bcast_tuple=bcast_tuple,
                obj='tm_comp', obj_val=self,
                mpi_pool=mpi_pool, concatenate=False)
        # Evaluate
        x = params['x']
        scatter_tuple = (['x'], [x])
        dmem_key_in_list = ['params_t']
        dmem_arg_in_list = ['precomp']
        dmem_val_in_list = [ params['params_t'] ]
        out = mpi_map("partial_xd", scatter_tuple=scatter_tuple,
                      dmem_key_in_list=dmem_key_in_list,
                      dmem_arg_in_list=dmem_arg_in_list,
                      dmem_val_in_list=dmem_val_in_list,
                      obj='tm_comp', obj_val=self,
                      mpi_pool=mpi_pool)
        return out[:,0]

    def minimize_kl_divergence_component_da_constraints(self, a, params):
        mpi_pool = params['mpi_pool']
        # Update coefficients
        bcast_tuple = (['coeffs'],[a])
        mpi_map("_set_coeffs", bcast_tuple=bcast_tuple,
                obj='tm_comp', obj_val=self,
                mpi_pool=mpi_pool, concatenate=False)
        # Evaluate
        x = params['x']
        scatter_tuple = (['x'], [x])
        dmem_key_in_list = ['params_t']
        dmem_arg_in_list = ['precomp']
        dmem_val_in_list = [ params['params_t'] ]
        out = mpi_map("grad_a_partial_xd", scatter_tuple=scatter_tuple,
                      dmem_key_in_list=dmem_key_in_list,
                      dmem_arg_in_list=dmem_arg_in_list,
                      dmem_val_in_list=dmem_val_in_list,
                      obj='tm_comp', obj_val=self,
                      mpi_pool=mpi_pool)
        return out[:,0,:] #.reshape( x.shape[0], self.n_coeffs )

    @staticmethod
    def from_xml_element(node, avars, totdim):
        import TransportMaps.Maps.Functionals as FUNC
        from TransportMaps import XML_NAMESPACE
        # Check span type
        multidimtype = node.attrib['multidimtype'] 
        if multidimtype == 'tensorized':
            stype = node.attrib['spantype']
            if stype == 'total' or stype == 'full':
                span_node, order_list, full_basis_list, basis_list = \
                    LinearSpanTensorizedParametricFunctional.parse_xml_span_node(node, avars, totdim)
                return PointwiseMonotoneLinearSpanTensorizedParametricFunctional(
                    basis_list, spantype=stype, order_list=order_list,
                    full_basis_list=full_basis_list)
            elif stype == 'midx':
                midxlist_node, midx_list, full_basis_list, basis_list = \
                    LinearSpanTensorizedParametricFunctional.parse_xml_midx_node(node, avars, totdim)
                return PointwiseMonotoneLinearSpanTensorizedParametricFunctional(
                    basis_list, spantype=stype, multi_idxs=midx_list,
                    full_basis_list=full_basis_list)
            raise ValueError("No recognizable spantype provided (%s)" % stype)
        raise ValueError("No recognizable multidimtype provided (%s)" % multidimtype)

##############
# DEPRECATED #
##############

class MonotonicLinearSpanApproximation(
        PointwiseMonotoneLinearSpanTensorizedParametricFunctional
):
    @deprecate(
        'MonotonicLinearSpanApproximation',
        '3.0',
        'Use Functionals.PointwiseMonotoneLinearSpanTensorizedParametricFunctional instead.'
    )
    def __init__(self, *args, **kwargs):
        super(MonotonicLinearSpanApproximation, self).__init__(*args, **kwargs)
