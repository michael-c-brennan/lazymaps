#
# This file is part of TransportMaps.
#
# TransportMaps is free software: you can redistribute it and/or modify
# it under the terms of the GNU Lesser General Public License as published by
# the Free Software Foundation, either version 3 of the License, or
# (at your option) any later version.
#
# TransportMaps is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU Lesser General Public License for more details.
#
# You should have received a copy of the GNU Lesser General Public License
# along with TransportMaps.  If not, see <http://www.gnu.org/licenses/>.
#
# Transport Maps Library
# Copyright (C) 2015-2018 Massachusetts Institute of Technology
# Uncertainty Quantification group
# Department of Aeronautics and Astronautics
#
# Authors: Transport Map Team
# Website: transportmaps.mit.edu
# Support: transportmaps.mit.edu/qa/
#

import logging
import numpy as np
import numpy.linalg as npla
import scipy.optimize as sciopt

from TransportMaps.Misc import mpi_map, mpi_map_alloc_dmem, mpi_bcast_dmem, \
    SumChunkReduce, deprecate
from TransportMaps.Routines import \
    kl_divergence_component, grad_a_kl_divergence_component, \
    hess_a_kl_divergence_component

from .ParametricFunctionalBase import ParametricFunctional
from .MonotoneFunctionalBase import MonotoneFunctional

__all__ = [
    'ParametricMonotoneFunctional',
    'MonotonicFunctionApproximation'
]

class ParametricMonotoneFunctional(
        ParametricFunctional,
        MonotoneFunctional
):
    r""" Abstract class for the prametric functional :math:`f \approx f_{\bf a} = \sum_{{\bf i} \in \mathcal{I}} {\bf a}_{\bf i} \Phi_{\bf i}` assumed to be monotonic in :math:`x_d`
    """

    def get_identity_coeffs(self):
        raise NotImplementedError("To be implemented in subclasses")
        
    def get_default_init_values_regression(self):
        return self.get_identity_coeffs()

    def regression_callback(self, xk):
        self.params_callback['hess_assembled'] = False

    def _regression_nominal_coeffs(self):
        return self.get_identity_coeffs()
        
    def regression(self, f, fparams=None, d=None, qtype=None, qparams=None,
                   x=None, w=None, x0=None, regularization=None, tol=1e-4, maxit=100,
                   batch_size=(None,None,None), mpi_pool=None, import_set=set()):
        r""" Compute :math:`{\bf a}^* = \arg\min_{\bf a} \Vert f - f_{\bf a} \Vert_{\pi}`.

        Args:
          f (:class:`Function` or :class:`ndarray<numpy.ndarray>` [:math:`m`]): function
            :math:`f` or its functions values
          fparams (dict): parameters for function :math:`f`
          d (Distribution): distribution :math:`\pi`
          qtype (int): quadrature type to be used for the approximation of
            :math:`\mathbb{E}_{\pi}`
          qparams (object): parameters necessary for the construction of the
            quadrature
          x (:class:`ndarray<numpy.ndarray>` [:math:`m,d`]): quadrature points
            used for the approximation of :math:`\mathbb{E}_{\pi}`
          w (:class:`ndarray<numpy.ndarray>` [:math:`m`]): quadrature weights
            used for the approximation of :math:`\mathbb{E}_{\pi}`
          x0 (:class:`ndarray<numpy.ndarray>` [:math:`N`]): coefficients to be used
            as initial values for the optimization
          regularization (dict): defines the regularization to be used.
            If ``None``, no regularization is applied.
            If key ``type=='L2'`` then applies Tikonhov regularization with
            coefficient in key ``alpha``.
          tol (float): tolerance to be used to solve the regression problem.
          maxit (int): maximum number of iterations
          batch_size (:class:`list<list>` [3] of :class:`int<int>`): the list contains the
            size of the batch to be used for each iteration. A size ``1`` correspond
            to a completely non-vectorized evaluation. A size ``None`` correspond to a
            completely vectorized one.
          mpi_pool (:class:`mpi_map.MPI_Pool`): pool of processes to be used
          import_set (set): list of couples ``(module_name,as_field)`` to be imported
            as ``import module_name as as_field`` (for MPI purposes)

        Returns:
          (:class:`tuple<tuple>`(:class:`ndarray<numpy.ndarray>` [:math:`N`],
          :class:`list<list>`)) -- containing the :math:`N` coefficients and
          log information from the optimizer.

        .. seealso:: :func:`TransportMaps.TriangularTransportMap.regression`

        .. note:: the resulting coefficients :math:`{\bf a}` are automatically
           set at the end of the optimization. Use :func:`coeffs` in order
           to retrieve them.
        
        .. note:: The parameters ``(qtype,qparams)`` and ``(x,w)`` are mutually
           exclusive, but one pair of them is necessary.
        """
        if (x is None) and (w is None):
            (x,w) = d.quadrature(qtype, qparams)
            
        params = {}
        params['x'] = x
        params['w'] = w
        params['regularization'] = regularization
        params['batch_size'] = batch_size
        params['nobj'] = 0
        params['nda_obj'] = 0
        params['nda2_obj'] = 0
        params['nda2_obj_dot'] = 0
        params['hess_assembled'] = False
        params['mpi_pool'] = mpi_pool
        options = {'maxiter': maxit,
                   'disp': False}
        if x0 is None:
            x0 = self.get_default_init_values_regression()
        if self.logger.getEffectiveLevel() <= logging.DEBUG:
            self.logger.debug("regression(): Precomputation started")
        if isinstance(f, np.ndarray):
            params['fvals'] = f
        else:
            scatter_tuple = (['x'], [x])
            bcast_tuple = (['precomp'], [fparams])
            params['fvals'] = mpi_map("evaluate", scatter_tuple=scatter_tuple,
                                      bcast_tuple=bcast_tuple,
                                      obj=f, mpi_pool=mpi_pool)
        # Init precomputation memory
        params['params1'] = {}
        mpi_bcast_dmem(params1=params['params1'], f1=self, mpi_pool=mpi_pool)
        # Precompute
        scatter_tuple = (['x'], [x])
        mpi_map("precomp_regression", scatter_tuple=scatter_tuple,
                dmem_key_in_list=['params1'],
                dmem_arg_in_list=['precomp'],
                dmem_val_in_list=[params['params1']],
                obj='f1', obj_val=self,
                mpi_pool=mpi_pool, concatenate=False)

        if self.logger.getEffectiveLevel() <= logging.DEBUG:
            self.logger.debug("regression(): Precomputation ended")

        # Callback variables
        self.params_callback = params

        # Minimize
        res = self._regression_call(args=params, x0=x0, tol=tol, options=options)
        if not res['success']:
            self.logger.warn("Regression failure: " + res['message'])

        # Clean up callback stuff
        del self.params_callback
        
        coeffs = res['x']
        self.coeffs = coeffs
        return (coeffs, res)

    def _regression_call(self, args, x0, tol, options):
        res = sciopt.minimize(
            self.regression_objective, args=args, x0=x0,
            jac=self.regression_grad_a_objective,
            # hessp=self.regression_action_storage_hess_a_objective,
            # method='Newton-CG',
            method='BFGS',
            tol=tol, options=options,
            callback=self.regression_callback)
        return res
        
    def get_default_init_values_minimize_kl_divergence_component(self):
        return self.get_identity_coeffs()

    def minimize_kl_divergence_component(self,
                                         f, x, w,
                                         x0=None,
                                         regularization=None,
                                         tol=1e-4, maxit=100, ders=2,
                                         fungrad=False, 
                                         precomp_type='uni',
                                         batch_size=None,
                                         cache_level=1,
                                         mpi_pool=None):
        r""" Compute :math:`{\bf a}^\star = \arg\min_{\bf a}-\sum_{i=0}^m \log\pi\circ T_k(x_i) + \log\partial_{x_k}T_k(x_i) = \arg\min_{\bf a}-\sum_{i=0}^m f(x_i)`

        Args:
          f (ProductDistributionParametricPullbackComponentFunction): function :math:`f` 
          x (:class:`ndarray<numpy.ndarray>` [:math:`m,d`]): quadrature points
          w (:class:`ndarray<numpy.ndarray>` [:math:`m`]): quadrature weights
          x0 (:class:`ndarray<numpy.ndarray>` [:math:`N`]): coefficients to be used
            as initial values for the optimization
          regularization (dict): defines the regularization to be used.
            If ``None``, no regularization is applied.
            If key ``type=='L2'`` then applies Tikonhov regularization with
            coefficient in key ``alpha``.
          tol (float): tolerance to be used to solve the KL-divergence problem.
          maxit (int): maximum number of iterations
          ders (int): order of derivatives available for the solution of the
            optimization problem. 0 -> derivative free, 1 -> gradient, 2 -> hessian.
          fungrad (bool): whether the distributions :math:`\pi_1,\pi_2` provide the method
            :func:`Distribution.tuple_grad_x_log_pdf` computing the evaluation and the
            gradient in one step. This is used only for ``ders==1``.
          precomp_type (str): whether to precompute univariate Vandermonde matrices 'uni' or
            multivariate Vandermonde matrices 'multi'
          batch_size (:class:`list<list>` [3 or 2] of :class:`int<int>` or :class:`list<list>` of ``batch_size``):
            the list contains the
            size of the batch to be used for each iteration. A size ``1`` correspond
            to a completely non-vectorized evaluation. A size ``None`` correspond to a
            completely vectorized one.
            If the target distribution is a :class:`ProductDistribution`, then
            the optimization problem decouples and
            ``batch_size`` is a list of lists containing the batch sizes to be
            used for each component of the map.
          cache_level (int): use high-level caching during the optimization, storing the
            function evaluation ``0``, and the gradient evaluation ``1`` or
            nothing ``-1``
          mpi_pool (:class:`mpi_map.MPI_Pool` or :class:`list<list>` of ``mpi_pool``):
            pool of processes to be used, ``None`` stands for one process.
            If the target distribution is a :class:`ProductDistribution`, then
            the minimization problem decouples and ``mpi_pool`` is a list containing
            ``mpi_pool``s for each component of the map.
        """
        self.logger.debug("minimize_kl_divergence_component(): Precomputation started")

        if batch_size is None:
            batch_size = [None] * 3
        # Distribute objects
        mpi_bcast_dmem(f=f, mpi_pool=mpi_pool)
        # Link tm_comp to f.tmap_component
        def link_tmcmp(f):
            return (f.tmap_component,)
        (tm_comp,) = mpi_map_alloc_dmem(
            link_tmcmp, dmem_key_in_list=['f'], dmem_arg_in_list=['f'],
            dmem_val_in_list=[f], dmem_key_out_list=['tm_comp'],
            mpi_pool=mpi_pool)
        # Init memory
        paramsf = {'params_pi': None,
                   'params_t': {} }
        mpi_bcast_dmem(paramsf=paramsf, mpi_pool=mpi_pool)
        dmem_key_in_list = ['paramsf']
        dmem_arg_in_list = ['params']
        dmem_val_in_list = [paramsf]
        # precomp_minimize_kl_divergence_component
        scatter_tuple = (['x'],[x])
        bcast_tuple = (['precomp_type'],[precomp_type])
        mpi_map("precomp_minimize_kl_divergence_component",
                scatter_tuple=scatter_tuple,
                bcast_tuple=bcast_tuple,
                dmem_key_in_list=dmem_key_in_list,
                dmem_arg_in_list=dmem_arg_in_list,
                dmem_val_in_list=dmem_val_in_list,
                obj='tm_comp', obj_val=tm_comp,
                mpi_pool=mpi_pool, concatenate=False)
        # allocate_cache_minimize_kl_divergence_component
        scatter_tuple = (['x'],[x])
        (cache, ) = mpi_map_alloc_dmem(
            "allocate_cache_minimize_kl_divergence_component",
            scatter_tuple=scatter_tuple,
            dmem_key_out_list=['cache'],
            obj='tm_comp', obj_val=tm_comp,
            mpi_pool=mpi_pool, concatenate=False)
        self.logger.debug("minimize_kl_divergence(): Precomputation ended")
        params = {}
        params['nobj'] = 0
        params['nda_obj'] = 0
        params['nda2_obj'] = 0
        params['nda2_obj_dot'] = 0
        params['x'] = x
        params['w'] = w
        params['f'] = f
        params['paramsf'] = paramsf
        params['cache'] = cache
        params['batch_size'] = batch_size
        params['regularization'] = regularization
        params['hess_assembled'] = False
        params['mpi_pool'] = mpi_pool

        if x0 is None:
            x0 = self.get_default_init_values_minimize_kl_divergence_component()

        params['objective_cache_coeffs'] = x0 - 1.
        
        # Callback variables
        self.it_callback = 0
        self.ders_callback = ders
        self.params_callback = params

        # Options for optimizer
        options = {'maxiter': maxit,
                   'disp': False}

        # Solve
        if ders == 0:
            res = sciopt.minimize(self.minimize_kl_divergence_component_objective,
                                  args=params,
                                  x0=x0,
                                  method='BFGS',
                                  tol=tol,
                                  options=options,
                                  callback=self.minimize_kl_divergence_component_callback)
        elif ders == 1:
            if fungrad:
                raise NotImplementedError("Option fungrad not implemented for maps from samples")
                # res = sciopt.minimize(
                #     self.minimize_kl_divergence_component_tuple_grad_a_objective,
                #     args=params,
                #     x0=x0,
                #     jac=True,
                #     method='BFGS',
                #     tol=tol,
                #     options=options,
                #     callback=self.minimize_kl_divergence_component_callback)
            else:
                res = sciopt.minimize(
                    self.minimize_kl_divergence_component_objective,
                    args=params,
                    x0=x0,
                    jac=self.minimize_kl_divergence_component_grad_a_objective,
                    method='BFGS',
                    tol=tol,
                    options=options,
                    callback=self.minimize_kl_divergence_component_callback)
        elif ders == 2:
            res = sciopt.minimize(
                self.minimize_kl_divergence_component_objective, args=params, x0=x0,
                jac=self.minimize_kl_divergence_component_grad_a_objective,
                hess=self.minimize_kl_divergence_component_hess_a_objective,
                method='newton-cg', tol=tol, options=options,
                callback=self.minimize_kl_divergence_component_callback)

        # Clean up callback stuff
        del self.it_callback
        del self.ders_callback
        del self.params_callback

        # Log
        log = {}
        log['success'] = res['success']
        log['message'] = res['message']
        log['fval'] = res['fun']
        log['nit'] = res['nit']
        log['n_fun_ev'] = params['nobj']
        if ders >= 1:
            log['n_jac_ev'] = params['nda_obj']
            log['jac'] = res['jac']
        if ders >= 2:
            log['n_hess_ev'] = params['nda2_obj']
        # Display stats
        if log['success']:
            self.logger.info("Optimization terminated successfully")
        else:
            self.logger.info("Optimization failed.")
            self.logger.info("Message: %s" % log['message'])
        self.logger.info("  Function value:          %6f" % log['fval'])
        if ders >= 1:
            self.logger.info("  Norm of the Jacobian:    %6f" % npla.norm(log['jac']))
        self.logger.info("  Number of iterations:    %6d" % log['nit'])
        self.logger.info("  N. function evaluations: %6d" % log['n_fun_ev'])
        if ders >= 1:
            self.logger.info("  N. Jacobian evaluations: %6d" % log['n_jac_ev'])
        if ders >= 2:
            self.logger.info("  N. Hessian evaluations:  %6d" % log['n_hess_ev'])
        
        # Set coefficients
        self.coeffs = res['x']
        return log

    def precomp_minimize_kl_divergence_component(self, x, params, precomp_type='uni'):
        r""" Precompute necessary structures for the speed up of :func:`minimize_kl_divergence_component`

        Args:
          x (:class:`ndarray<numpy.ndarray>` [:math:`m,d`]): evaluation points
          params (dict): parameters to be updated
          precomp_type (str): whether to precompute univariate Vandermonde matrices 'uni' or
            multivariate Vandermonde matrices 'multi'

        Returns:
           (:class:`tuple<tuple>` (None,:class:`dict<dict>`)) -- dictionary of necessary
              strucutres. The first argument is needed for consistency with 
        """
        self.precomp_evaluate(x, params['params_t'], precomp_type)
        self.precomp_partial_xd(x, params['params_t'], precomp_type)

    def allocate_cache_minimize_kl_divergence_component(self, x):
        r""" Allocate cache space for the KL-divergence minimization

        Args:
          x (:class:`ndarray<numpy.ndarray>` [:math:`m,d`]): evaluation points
        """
        cache = {'tot_size': x.shape[0]}
        return (cache, )

    def reset_cache_minimize_kl_divergence_component(self, cache):
        r""" Reset the objective part of the cache space for the KL-divergence minimization

        Args:
          params2 (dict): dictionary of precomputed values
        """
        tot_size = cache['tot_size']
        cache.clear()
        cache['tot_size'] = tot_size

    def minimize_kl_divergence_component_callback(self, xk):
        self.it_callback += 1
        if self.logger.getEffectiveLevel() <= logging.DEBUG:
            self.logger.debug("Iteration %d" % self.it_callback)
        if self.ders_callback == 2:
            self.params_callback['hess_assembled'] = False

    def minimize_kl_divergence_component_objective(self, a, params):
        r""" Objective function :math:`-\sum_{i=0}^m f(x_i) = -\sum_{i=0}^m \log\pi\circ T_k(x_i) + \log\partial_{x_k}T_k(x_i)`

        Args:
          a (:class:`ndarray<numpy.ndarray>` [:math:`N`]): coefficients
          params (dict): dictionary of parameters
        """
        params['nobj'] += 1
        x = params['x']
        w = params['w']
        f = params['f']
        paramsf = params['paramsf']
        cache = params['cache']
        batch_size = params['batch_size']
        mpi_pool = params['mpi_pool']
        # Update coefficients
        self.coeffs = a
        bcast_tuple = (['coeffs'],[a])
        mpi_map("_set_coeffs", bcast_tuple=bcast_tuple,
                obj='tm_comp', obj_val=self,
                mpi_pool=mpi_pool, concatenate=False)
        # Reset cache
        if (params['objective_cache_coeffs'] != self.coeffs).any():
            params['objective_cache_coeffs'] = self.coeffs.copy()
            dmem_key_in_list = ['cache']
            dmem_arg_in_list = ['cache']
            dmem_val_in_list = [cache]
            mpi_map("reset_cache_minimize_kl_divergence_component",
                    dmem_key_in_list=dmem_key_in_list,
                    dmem_arg_in_list=dmem_arg_in_list,
                    dmem_val_in_list=dmem_val_in_list,
                    obj='tm_comp', obj_val=self,
                    mpi_pool=mpi_pool,
                    concatenate=False)
        # Evaluate KL-divergence
        scatter_tuple = (['x', 'w'],[x, w])
        bcast_tuple = (['batch_size'],
                       [batch_size[0]])
        dmem_key_in_list = ['f', 'paramsf', 'cache']
        dmem_arg_in_list = ['f', 'params', 'cache']
        dmem_val_in_list = [f, paramsf, cache]
        reduce_obj = SumChunkReduce(axis=0)
        out = mpi_map(kl_divergence_component,
                      scatter_tuple=scatter_tuple,
                      bcast_tuple=bcast_tuple,
                      dmem_key_in_list=dmem_key_in_list,
                      dmem_arg_in_list=dmem_arg_in_list,
                      dmem_val_in_list=dmem_val_in_list,
                      reduce_obj=reduce_obj,
                      mpi_pool=mpi_pool)
        if params['regularization'] == None:
            pass
        elif params['regularization']['type'] == 'L2':
            centered_coeffs = a - self.get_identity_coeffs()
            out += params['regularization']['alpha'] * npla.norm(centered_coeffs,2)**2.
        elif params['regularization']['type'] == 'L1':
            # using ||a||_1 regularization (not squared)
            centered_coeffs = a - self.get_identity_coeffs() 
            out += params['regularization']['alpha'] * npla.norm(centered_coeffs,1)
        self.logger.debug("KL Obj. Eval. %d - KL-divergence = %.10e" % (params['nobj'], out))
        return out
        
    def minimize_kl_divergence_component_grad_a_objective(self, a, params):
        r""" Gradient of the objective function :math:`-\sum_{i=0}^m \nabla_{\bf a} f[{\bf a}](x_i) = -\sum_{i=0}^m \nabla_{\bf a} \left( \log\pi\circ T_k[{\bf a}](x_i) + \log\partial_{x_k}T_k[{\bf a}](x_i)\right)`

        Args:
          a (:class:`ndarray<numpy.ndarray>` [:math:`N`]): coefficients
          params (dict): dictionary of parameters
        """
        params['nda_obj'] += 1
        x = params['x']
        w = params['w']
        f = params['f']
        paramsf = params['paramsf']
        cache = params['cache']
        batch_size = params['batch_size']
        mpi_pool = params['mpi_pool']
        # Update coefficients
        self.coeffs = a
        bcast_tuple = (['coeffs'],[a])
        mpi_map("_set_coeffs", bcast_tuple=bcast_tuple,
                obj='tm_comp', obj_val=self,
                mpi_pool=mpi_pool, concatenate=False)
        # Reset cache
        if (params['objective_cache_coeffs'] != self.coeffs).any():
            params['objective_cache_coeffs'] = self.coeffs.copy()
            # Reset cache
            dmem_key_in_list = ['cache']
            dmem_arg_in_list = ['cache']
            dmem_val_in_list = [cache]
            mpi_map("reset_cache_minimize_kl_divergence_component",
                    dmem_key_in_list=dmem_key_in_list,
                    dmem_arg_in_list=dmem_arg_in_list,
                    dmem_val_in_list=dmem_val_in_list,
                    obj='tm_comp', obj_val=self,
                    mpi_pool=mpi_pool,
                    concatenate=False)
        # Evaluate KL-divergence
        scatter_tuple = (['x', 'w'],[x, w])
        bcast_tuple = (['batch_size'],
                       [batch_size[0]])
        dmem_key_in_list = ['f', 'paramsf']
        dmem_arg_in_list = ['f', 'params']
        dmem_val_in_list = [f, paramsf]
        reduce_obj = SumChunkReduce(axis=0)
        out = mpi_map(grad_a_kl_divergence_component,
                      scatter_tuple=scatter_tuple,
                      bcast_tuple=bcast_tuple,
                      dmem_key_in_list=dmem_key_in_list,
                      dmem_arg_in_list=dmem_arg_in_list,
                      dmem_val_in_list=dmem_val_in_list,
                      reduce_obj=reduce_obj,
                      mpi_pool=mpi_pool)
        if params['regularization'] == None:
            pass
        elif params['regularization']['type'] == 'L2':
            out += params['regularization']['alpha'] * 2. * a
        if self.logger.getEffectiveLevel() <= logging.DEBUG:
            self.logger.debug("KL Grad_a Obj. Eval. %d - ||grad_a KLdiv|| = %.10e" % (
                params['nda_obj'], npla.norm(out)))
        return out

    def minimize_kl_divergence_component_hess_a_objective(self, a, params):
        r""" Hessian of the objective function :math:`-\sum_{i=0}^m \nabla^2_{\bf a} f[{\bf a}](x_i) = -\sum_{i=0}^m \nabla^2_{\bf a} \left( \log\pi\circ T_k[{\bf a}](x_i) + \log\partial_{x_k}T_k[{\bf a}](x_i)\right)`

        Args:
          a (:class:`ndarray<numpy.ndarray>` [:math:`N`]): coefficients
          params (dict): dictionary of parameters
        """
        params['nda2_obj'] += 1
        x = params['x']
        w = params['w']
        f = params['f']
        paramsf = params['paramsf']
        cache = params['cache']
        batch_size = params['batch_size']
        mpi_pool = params['mpi_pool']
        # Update coefficients
        self.coeffs = a
        bcast_tuple = (['coeffs'],[a])
        mpi_map("_set_coeffs", bcast_tuple=bcast_tuple,
                obj='tm_comp', obj_val=self,
                mpi_pool=mpi_pool, concatenate=False)
        # Reset cache
        if (params['objective_cache_coeffs'] != self.coeffs).any():
            params['objective_cache_coeffs'] = self.coeffs.copy()
            # Reset cache
            dmem_key_in_list = ['cache']
            dmem_arg_in_list = ['cache']
            dmem_val_in_list = [cache]
            mpi_map("reset_cache_minimize_kl_divergence_component",
                    dmem_key_in_list=dmem_key_in_list,
                    dmem_arg_in_list=dmem_arg_in_list,
                    dmem_val_in_list=dmem_val_in_list,
                    obj='tm_comp', obj_val=self,
                    mpi_pool=mpi_pool,
                    concatenate=False)
        # Evaluate KL-divergence
        scatter_tuple = (['x', 'w'],[x, w])
        bcast_tuple = (['batch_size'],
                       [batch_size[0]])
        dmem_key_in_list = ['f', 'paramsf']
        dmem_arg_in_list = ['f', 'params']
        dmem_val_in_list = [f, paramsf]
        reduce_obj = SumChunkReduce(axis=0)
        out = mpi_map(hess_a_kl_divergence_component,
                      scatter_tuple=scatter_tuple,
                      bcast_tuple=bcast_tuple,
                      dmem_key_in_list=dmem_key_in_list,
                      dmem_arg_in_list=dmem_arg_in_list,
                      dmem_val_in_list=dmem_val_in_list,
                      reduce_obj=reduce_obj,
                      mpi_pool=mpi_pool)
        if params['regularization'] == None:
            pass
        elif params['regularization']['type'] == 'L2':
            out += np.diag( np.ones(self.n_coeffs)*2.*params['regularization']['alpha'] )
        if self.logger.getEffectiveLevel() <= logging.DEBUG:
            self.logger.debug("KL Hess_a Obj. Eval. %d " % params['nda2_obj'])
        return out

##############
# DEPRECATED #
##############

class MonotonicFunctionApproximation(ParametricMonotoneFunctional):
    @deprecate(
        'MonotonicFunctionApproximation',
        '3.0',
        'Use Funtionals.ParametricMonotoneFunctional instead.'
    )
    def __init__(self, *args, **kwars):
        super(MonotonicFunctionApproximation, self).__init__(*args, **kwars)
