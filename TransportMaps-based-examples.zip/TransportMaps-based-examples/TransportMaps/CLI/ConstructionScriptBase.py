#
# This file is part of TransportMaps.
#
# TransportMaps is free software: you can redistribute it and/or modify
# it under the terms of the GNU Lesser General Public License as published by
# the Free Software Foundation, either version 3 of the License, or
# (at your option) any later version.
#
# TransportMaps is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU Lesser General Public License for more details.
#
# You should have received a copy of the GNU Lesser General Public License
# along with TransportMaps.  If not, see <http://www.gnu.org/licenses/>.
#
# Transport Maps Library
# Copyright (C) 2015-2018 Massachusetts Institute of Technology
# Uncertainty Quantification group
# Department of Aeronautics and Astronautics
#
# Author: Transport Map Team
# Website: transportmaps.mit.edu
# Support: transportmaps.mit.edu/qa/
#

import sys
import os.path
import dill
import logging
import numpy as np
import numpy.random as npr
import scipy.stats as stats

from . import AvailableOptions as AO
from .ScriptBase import Script

import TransportMaps as TM
import TransportMaps.Maps as MAPS
import TransportMaps.Distributions as DIST
import TransportMaps.Diagnostics as DIAG
import TransportMaps.XML as TMXML
import TransportMaps.Builders as BUILD
import TransportMaps.Algorithms.Adaptivity as ALGADPT

if sys.version_info[0] == 2:
    input = raw_input

__all__ = ['ConstructionScript']
    
class ConstructionScript(Script):

    # USAGE STRINGS
    cmd_usage_str = "Usage: tmap-tm "
    opts_usage_str = """[-h -I] 
  --input=DIST --output=OUTPUT [--base-dist=BASE_DIST]
  (--mtype=MTYPE --span=SPAN --btype=BTYPE --order=ORDER --sparsity=SPARSITY)
    / (--map-descr=MAP_DESCR)
    / (--map-pkl=MAP_PKL)
    / (--map-factory-pkl=PKL)
  --qtype=QTYPE --qnum=QNUM
  [--tol=TOL --maxit=MAXIT --reg=REG --ders=DERS --fungrad --hessact]
  [--validator=VNAME --val-eps=FLOAT --val-cost-fun=CFUN
   --val-max-cost=LIM --val-max-nsamps=LIM --val-stop-on-fcast]
  [--val-saa-eps-abs=EPS --val-saa-upper-mul=UMUL --val-saa-lower-n=LOWN 
   --val-saa-alpha=ALPHA --val-saa-lmb-def=LDEF --val-saa-lmb-max=LMAX]
  [--val-gradboot-delta=FLOAT --val-gradboot-n-grad=INT --val-gradboot-n-boot=INT
   --val-gradboot-alpha=FLOAT --val-gradboot-lmb-min=INT --val-gradboot-lmb-max=INT]
  [--adapt=none --adapt-tol=TOL --adapt-verbosity=VAL]
  [--adapt-regr=REGR --adapt-regr-reg=REG
   --adapt-regr-tol=TOL --adapt-regr-maxit=MAXIT]
  [--adapt-fv-maxit=MAXIT
   --adapt-fv-prune-trunc-type=TYPE --adapt-fv-prune-trunc-val=VAL
   --adapt-fv-avar-trunc-type=TYPE --adapt-fv-avar-trunc-val=EPS
   --adapt-fv-coeff-trunc-type=TYPE --adapt-fv-coeff-trunc-val=VAL
   --adapt-fv-ls-maxit=MAXIT --adapt-fv-ls-delta=DEL
   --adapt-fv-interactive]
  [--adapt-lazy-maxit=MAXIT
   --adapt-lazy-rank-max=VAL --adapt-lazy-rank-eps=VAL
   --adapt-lazy-rank-qtype=QTYPE --adapt-lazy-rank-qnum=QNUM]
  [--laplace-pull --map-pull=MAP]
  [--overwrite --reload --seed=N
   --log=LOG --nprocs=NPROCS --batch=INT,INT,INT]
"""

    # DOCUMENTATION STRINGS
    docs_monotone_str = \
        '  --mtype=MTYPE           monotone format for the transport\n' + \
        AO.print_avail_options(AO.AVAIL_MONOTONE,'                          ')
    docs_span_str = \
        '  --span=SPAN             span type for all the components of the map\n' + \
        AO.print_avail_options(AO.AVAIL_SPAN,'                          ')
    docs_btype_str = \
        '  --btype=BTYPE           basis types for all the components of the map\n' + \
        AO.print_avail_options(AO.AVAIL_BTYPE,'                          ')
    docs_sparsity_str = \
        '  --sparsity=SPARSITY     sparsity pattern (default: tri) \n' + \
        AO.print_avail_options(AO.AVAIL_SPARSITY,'                          ')
    docs_qtype_str = \
        '  --qtype=QTYPE           quadrature type for the discretization of ' + \
        'the KL-divergence\n' + \
        AO.print_avail_options(AO.AVAIL_QTYPE,'                          ')
    docs_ders_str = \
        '  --ders=DERS             derivatives to be used in the optimization\n' + \
        AO.print_avail_options(AO.AVAIL_DERS,'                          ')
    docs_validator_str = \
        '  --validator=VNAME       valiator to be used (default: none)\n' + \
        AO.print_avail_options(AO.AVAIL_VALIDATOR,'                          ')
    docs_cost_function_str = \
        '  --val-cost-fun=CFUN     cost function (default: tot-time)\n' + \
        AO.print_avail_options(AO.AVAIL_COST_FUNCTION,'                          ')
    docs_adaptivity_str = \
        '  --adapt=ADAPT           adaptivity algorithm for map construction\n' + \
        AO.print_avail_options(AO.AVAIL_ADAPTIVITY,'                          ')
    docs_adapt_coeff_truncation_str = \
        '  --adapt-fv-coeff-trunc-type=TYPE [FV] type of enrichment truncation\n' + \
        AO.print_avail_options(AO.AVAIL_ADAPT_TRUNC,'                          ')
    docs_adapt_prune_truncation_str = \
        '  --adapt-fv-prune-trunc-type=TYPE [FV] type of pruning truncation\n' + \
        AO.print_avail_options(AO.AVAIL_ADAPT_TRUNC,'                          ')
    docs_adapt_avar_truncation_str = \
        '  --adapt-fv-avar-trunc-type=TYPE [FV] type of active variable truncation\n' + \
        AO.print_avail_options(AO.AVAIL_ADAPT_TRUNC,'                          ')
    docs_regression_adaptivity_str = \
        '  --adapt-regr=REGR       regression algorithm to be used within adaptivity\n' + \
        AO.print_avail_options(AO.AVAIL_REGRESSION_ADAPTIVITY,
                                  '                          ')
    docs_log_str = \
        '  --log=LOG               log level (default=30). Uses package logging.\n' + \
        AO.print_avail_options(AO.AVAIL_LOGGING,'                          ')

    docs_descr_str = """DESCRIPTION
Given a file (--input) storing the target distribution, produce the transport map that
pushes forward the base distribution (default: standard normal) to the target distribution.
All files involved are stored and loaded using the python package dill."""
    
    docs_options_str = """

OPTIONS - input/output:
  --input=DIST            path to the file containing the target distribution 
  --output=OUTPUT         path to the output file containing the transport map,  
                          the base distribution, the target distribution and all 
                          the additional parameters used for the construction 
  --base-dist=BASE_DIST   path to the file containing the base distribution
                          (default: a standard normal of suitable dimension)
OPTIONS - map description (using default maps):
""" + docs_monotone_str + docs_span_str + docs_btype_str + \
"""  --order=ORDER           order of the transport map
""" + docs_sparsity_str + \
"""OPTIONS - map description (manual):
  --map-descr=MAP_DESCR   XML file containing the skeleton of the transport map
OPTIONS - serialized map (manual):
  --map-pkl=MAP_PKL       unpickable (dill) file containing the map to be used.
                          It may be a comma separated list of files, containing the
                          maps to be used for sequential adaptation schemes.
                          In the latter case the maps must be nested (i.e. the next
                          map must be an enrichment of the previous map).
                          The map must be of the correct dimension
  --map-factory-pkl=PKL   unpickable (dill) file containing a map factory
                          (instance of MapFactory or MapListFactory) used to
                          generate maps (or list of maps). This is used for only
                          algorithms based on tmap-tm, not by tmap-tm itself.
                          Therefore this option is not sufficient/necessary
                          to run tmap-tm itself.
OPTIONS - solver:
""" + docs_qtype_str + \
"""  --qnum=QNUM             quadrature level
  --tol=TOL               kl minimization tolerance (default: 1e-4)
  --maxit=MAXIT           maximum number of iterations for kl minimization
  --reg=REG               a float L2 regularization parameter
                          (default: no regularization)
""" + docs_ders_str + \
"""  --fungrad               whether the distributions provide a method to compute
                          the log pdf and its gradient at the same time
  --hessact               whether to use the action of the Hessian
""" + docs_validator_str + \
"""  --val-eps=EPS           target tolerance for solution of the stochastic program (default: 1e-2)
""" + docs_cost_function_str + \
"""  --val-max-cost=LIM      total cost limit (default: 1000)
  --val-max-nsamps=LIM    maximum number of samples to use in the approximation of
                          the expecations (default: infinity)
  --val-stop-on-fcast     whether to stop on a forecast to exceed the cost limit
                          (by default it stops only after exceeding the cost limit)
  --val-saa-eps-abs=EPS   [SAA] absolute error to be used (--val-eps is relative)
  --val-saa-upper-mult=VAL [SAA] upper multiplier (default: 10)
  --val-saa-lower-n=VAL   [SAA] number of samples for lower bound (default: 2)
  --val-saa-alpha=VAL     [SAA] quantile (defalt: 0.05)
  --val-saa-lmb-def=VAL   [SAA] default refinement multiplier (default: 2)
  --val-saa-lmb-max=VAL   [SAA] maximum refinement multiplier (default: 10)
  --val-gradboot-delta=FLOAT [GRADBOOT] multiplicative factor of the gradient obtained (default: 5)
  --val-gradboot-n-grad=INT [GRADBOOT] multiplicative factor for the bootstrap sample size (default: 1)
  --val-gradboot-n-boot=INT [GRADBOOT] number of bootstrap repicas (default: 2000)
  --val-gardboot-alpha=FLOAT [GRADBOOT] tolerance interval quantile (default: .95)
  --val-gradboot-lmb-min=INT [GRADBOOT] minimum refinement multiplier (default: 2)
  --val-gradboot-lmb-max=INT [GRADBOOT] maximum refinement multiplier (default: 10)
""" + docs_adaptivity_str + \
"""  --adapt-tol=TOL         target variance diagnostic tolerance
  --adapt-verbosity=VAL   This regulates the amount of information printed by the logger.
                          Values are >0 with higher values corresponding to higher verbosity.
                          Default is 0.
""" + docs_regression_adaptivity_str + \
"""  --adapt-regr-reg=REG    regularization to be used in regression
  --adapt-regr-tol=TOL    regression tolerance
  --adapt-regr-maxit=MAXIT maximum number of iteration in regression
  --adapt-fv-maxit=MAXIT [FV] maximum number of iterations (default: 20)
""" + docs_adapt_prune_truncation_str + \
"""  --adapt-fv-prune-trunc-val=VAL [FV] prune truncation parameter (default: None)
""" + docs_adapt_avar_truncation_str + \
"""  --adapt-fv-avar-trunc-val=EPS [FV] active variables trunc parameter (default: .1)
""" + docs_adapt_coeff_truncation_str + \
"""  --adapt-fv-coeff-trunc-val=VAL [FV] coefficient truncation parameter (default: 10)
  --adapt-fv-ls-maxit=MAXIT [FV] maximum number of line search
                          iterations (default: 20)
  --adapt-fv-ls-delta=DEL [FV] initial step size for line search
  --adapt-fv-interactive  [FV] whether to query the user for approval to continue
  --laplace-pull          whether to precondition pulling back the target through
                          its Laplace approximation
  --map-pull=MAP          path to file containing a map through which to pullback 
                          the target (this is done before pulling back thorugh
                          the Laplace, if --laplace-pull is provided).
                          The file may cointain just the map or may be the output
                          of any other map construction scripts (tmap-tm, ...)
  --overwrite             overwrite file if it exists
  --reload                reload file if it exists
  --seed=N                random seed to be used (default: no seed)
""" + docs_log_str + \
"""  --nprocs=INT            number of processors to be used (default=1)
  --batch=INT,INT,INT     batch size for evaluation of function, gradient and Hessian
OPTIONS - other:
  -I                      enter interactive mode after finishing
  -h                      print this help
"""
        
    @property
    def long_options(self):
        return super(ConstructionScript, self).long_options + \
            [
                # I/O
                "base-dist=",
                # Map type
                "mtype=", "span=", "btype=", "order=", "sparsity=",
                "map-descr=",
                "map-pkl=",
                "map-factory-pkl=",
                # Quadrature type
                "qtype=", "qnum=",
                # Solver options
                "tol=", "maxit=", "reg=", "ders=", "fungrad", "hessact",
                # Validation
                "validator=", "val-eps=",
                "val-cost-fun=", "val-max-cost=",
                "val-max-nsamps=", "val-stop-on-fcast",
                # Sample average approximation validator
                "val-saa-eps-abs=", "val-saa-upper-mult=", "val-saa-lower-n=",
                "val-saa-alpha=", "val-saa-lmb-def=", "val-saa-lmb-max=",
                # Gradient bootstrap validator
                "val-gradboot-delta=", "val-gradboot-n-grad=",
                "val-gradboot-n_boot=", "val-gradboot-alpha",
                "val-gradboot-lmb-min=", "val-gradboot-lmb-max=",
                # Adaptivity options
                "adapt=", "adapt-tol=", "adapt-verbosity=",
                "adapt-regr=", "adapt-regr-reg=", "adapt-regr-tol=", "adapt-regr-maxit=",
                "adapt-fv-maxit=",
                "adapt-fv-prune-trunc-type=", "adapt-fv-prune-trunc-val=",
                "adapt-fv-avar-trunc-type=", "adapt-fv-avar-trunc-val=",
                "adapt-fv-coeff-trunc-type=", "adapt-fv-coeff-trunc-val=",
                "adapt-fv-ls-maxit=", 'adapt-fv-ls-delta=',
                "adapt-fv-interactive",
                # Whether to pre-pull through Laplace or a user provided map
                "laplace-pull",
                "map-pull=",
                # Overwriting and reloading
                "overwrite", "reload",
                # Random seed
                "seed=",
                # batching option
                "batch="
            ]

    def _load_opts(self, opts):
        super(ConstructionScript, self)._load_opts(opts)
        
        for opt, arg in opts:
            # I/O
            if opt in ['--base-dist']:
                self.BASE_DIST_FNAME = arg

            # Map type
            elif opt in ['--mtype']:
                self.MONOTONE = arg
            elif opt in ['--span']:
                self.SPAN = arg
            elif opt in ['--btype']:
                self.BTYPE = arg        
            elif opt in ['--order']:
                self.ORDER = int(arg)
            elif opt in ['--sparsity']:
                if arg not in AO.AVAIL_SPARSITY:
                    self.usage()
                    self.tstamp_print("ERROR: Argument %s for --sparsity not recognized" % arg)
                    sys.exit(3)
                self.SPARSITY = arg
            elif opt in ['--map-descr']:
                self.MAP_DESCR = arg
            elif opt in ['--map-pkl']:
                self.MAP_PKL = arg
            elif opt in ['--map-factory-pkl']:
                self.MAP_FACTORY_PKL = arg

            # Quadrature type
            elif opt in ['--qtype']:
                self.stg.QTYPE = int(arg)
            elif opt in ['--qnum']:
                self.stg.QNUM = [int(q) for q in arg.split(',')]

            # Solver options
            elif opt in ['--tol']:
                self.stg.TOL = float(arg)
            elif opt == '--maxit':
                self.stg.MAXIT = int(arg)
            elif opt in ['--reg']:
                self.stg.REG = [ {'type': 'L2', 'alpha': float(q)}
                            for q in arg.split(',') ]
            elif opt in ['--ders']:
                self.stg.DERS = int(arg)
            elif opt == '--fungrad':
                self.stg.FUNGRAD = True
            elif opt == '--hessact':
                self.stg.HESSACT = True

            # Validation options
            elif opt == '--validator':
                if  arg not in AO.AVAIL_VALIDATOR:
                    self.usage()
                    self.tstamp_print("ERROR: Argument %s for --validator not recognized" % arg)
                    sys.exit(3)
                self.stg.VALIDATOR = arg
            elif opt == '--val-eps':
                self.stg.VAL_EPS = float(arg)
            elif opt == '--val-cost-fun':
                if arg not in AO.AVAIL_COST_FUNCTION:
                    self.usage()
                    self.tstamp_print("ERROR: Argument %s for --val-cost-fun not recognized" % arg)
                    sys.exit(3)
                self.stg.VAL_COST_FUN = arg
            elif opt == '--val-max-cost':
                self.stg.VAL_MAX_COST = float(arg)
            elif opt == '--val-max-nsamps':
                self.stg.VAL_MAX_NSAMPS = int(arg)
            elif opt == '--val-stop-on-fcast':
                self.stg.VAL_STOP_ON_FCAST = True
            # Sample average approximation options
            elif opt == '--val-saa-eps-abs':
                self.stg.VAL_SAA_EPS_ABS = float(arg)
            elif opt == '--val-saa-upper-mult':
                self.stg.VAL_SAA_UPPER_MULT = float(arg)
            elif opt == '--val-saa-lower-n':
                self.stg.VAL_SAA_LOWER_N = int(arg)
            elif opt == '--val-saa-alpha':
                self.stg.VAL_SAA_ALPHA = float(alpha)
            elif opt == '--val-saa-lmb-def':
                self.stg.VAL_SAA_LMB_DEF = float(arg)
            elif opt == '--val-saa-lmb-max':
                self.stg.VAL_SAA_LMB_MAX = float(arg)
            # Gradient bootstrap validation options
            elif opt == '--val-gradboot-delta':
                self.stg.VAL_GRADBOOT_DELTA = float(arg)
            elif opt == '--val-gradboot-n-grad':
                self.stg.VAL_GRADBOOT_N_GRAD = int(arg)
            elif opt == '--val-gradboot-n-boot':
                self.stg.VAL_GRADBOOT_N_BOOT = int(arg)
            elif opt == '--val-gradboot-alpha':
                self.stg.VAL_GRADBOOT_ALPHA = float(arg)
            elif opt == '--val-gradboot-lmb-min':
                self.stg.VAL_GRADBOOT_LMB_MIN = float(arg)
            elif opt == '--val-gradboot-lmb-max':
                self.stg.VAL_GRADBOOT_LMB_MAX = float(arg)

            # Adaptivity options
            elif opt == '--adapt':
                self.stg.ADAPT = arg
            elif opt == '--adapt-tol':
                self.stg.ADAPT_TOL = float(arg)
            elif opt == '--adapt-verbosity':
                self.stg.ADAPT_VERB = int(arg)
            elif opt == '--adapt-regr':
                if arg not in AO.AVAIL_REGRESSION_ADAPTIVITY:
                    self.usage()
                    self.tstamp_print("ERROR: Argument %s for --adapt-regr not recognized" % arg)
                    sys.exit(3)
                self.stg.ADAPT_REGR = arg
            elif opt == '--adapt-regr-reg':
                self.stg.ADAPT_REGR_REG = {'type': 'L2', 'alpha': float(arg)}
            elif opt == '--adapt-regr-tol':
                self.stg.ADAPT_REGR_TOL = float(arg)
            elif opt == '--adapt-regr-maxit':
                self.stg.ADAPT_REGR_MAX_IT = int(arg)
            elif opt == '--adapt-fv-maxit':
                self.stg.ADAPT_FV_MAX_IT = int(arg)
            elif opt == '--adapt-fv-prune-trunc-type':
                self.stg.ADAPT_FV_PRUNE_TRUNC_TYPE = arg
            elif opt == '--adapt-fv-prune-trunc-val':
                self.stg.ADAPT_FV_PRUNE_TRUNC_VAL = arg
            elif opt == '--adapt-fv-avar-trunc-type':
                self.stg.ADAPT_FV_AVAR_TRUNC_TYPE = arg
            elif opt == '--adapt-fv-avar-trunc-val':
                self.stg.ADAPT_FV_AVAR_TRUNC_VAL = arg
            elif opt == '--adapt-fv-coeff-trunc-type':
                self.stg.ADAPT_FV_COEFF_TRUNC_TYPE = arg
            elif opt == '--adapt-fv-coeff-trunc-val':
                self.stg.ADAPT_FV_COEFF_TRUNC_VAL = arg
            elif opt == '--adapt-fv-ls-maxit':
                self.stg.ADAPT_FV_LS_MAXIT = int(arg)
            elif opt == '--adapt-fv-ls-delta':
                self.stg.ADAPT_FV_LS_DELTA = float(arg)
            elif opt == '--adapt-fv-interactive':
                self.stg.ADAPT_FV_INTERACTIVE = True

            # Pre-pull 
            elif opt in ['--laplace-pull']:
                self.stg.LAPLACE_PULL = True
            elif opt == '--map-pull':
                self.stg.MAP_PULL = arg

            # Overwriting/reloading
            elif opt == '--overwrite':
                self.OVERWRITE = True
            elif opt == '--reload':
                self.RELOAD = True

            # Random seed
            elif opt == '--seed':
                self.stg.SEED = int(arg)

            # Batching
            elif opt in ['--batch']:
                self.BATCH_SIZE = [ int(s) for s in arg.split(',') ]

    def _init_self_variables(self):
        super(ConstructionScript, self)._init_self_variables()
        
        self.stg = TM.DataStorageObject()

        # I/O
        self.BASE_DIST_FNAME = None
        # Map type
        self.MONOTONE = None
        self.SPAN = None
        self.BTYPE = None
        self.ORDER = None
        self.SPARSITY = 'tri'
        self.MAP_DESCR = None
        self.MAP_PKL = None
        self.MAP_FACTORY_PKL = None
        # Validation
        self.stg.VALIDATOR = 'none'
        self.stg.VAL_EPS = 1e-2
        self.stg.VAL_COST_FUN = 'tot-time'
        self.stg.VAL_MAX_COST = np.inf
        self.stg.VAL_MAX_NSAMPS = np.inf
        self.stg.VAL_STOP_ON_FCAST = False
        # Sample average approximation validator
        self.stg.VAL_SAA_EPS_ABS = 1e-5
        self.stg.VAL_SAA_UPPER_MULT = 10
        self.stg.VAL_SAA_LOWER_N = 2
        self.stg.VAL_SAA_ALPHA = 0.05
        self.stg.VAL_SAA_LMB_DEF = 2
        self.stg.VAL_SAA_LMB_MAX = 10
        # Gradient bootstrap validator
        self.stg.VAL_GRADBOOT_DELTA = 5
        self.stg.VAL_GRADBOOT_N_GRAD = 1
        self.stg.VAL_GRADBOOT_N_BOOT = 2000
        self.stg.VAL_GRADBOOT_ALPHA = .95
        self.stg.VAL_GRADBOOT_LMB_MIN = 2
        self.stg.VAL_GRADBOOT_LMB_MAX = 10
        # Adaptivity
        self.stg.ADAPT = 'none'
        self.stg.ADAPT_TOL = 5e-2
        self.stg.ADAPT_VERB = 0
        self.stg.ADAPT_REGR = 'none'
        self.stg.ADAPT_REGR_REG = None
        self.stg.ADAPT_REGR_TOL = 1e-6
        self.stg.ADAPT_REGR_MAX_IT = 100
        self.stg.ADAPT_FV_MAX_IT = 20
        self.stg.ADAPT_FV_PRUNE_TRUNC_TYPE = 'manual'
        self.stg.ADAPT_FV_PRUNE_TRUNC_VAL = None
        self.stg.ADAPT_FV_AVAR_TRUNC_TYPE = 'manual'
        self.stg.ADAPT_FV_AVAR_TRUNC_VAL = None
        self.stg.ADAPT_FV_COEFF_TRUNC_TYPE = 'manual'
        self.stg.ADAPT_FV_COEFF_TRUNC_VAL = None
        self.stg.ADAPT_FV_LS_MAXIT = 20
        self.stg.ADAPT_FV_LS_DELTA = 2.
        self.stg.ADAPT_FV_INTERACTIVE = False
        # Quadrature type
        self.stg.QTYPE = None
        self.stg.QNUM = None
        # Solver options
        self.stg.TOL = 1e-4
        self.stg.MAXIT = 100
        self.stg.REG = None
        self.stg.DERS = 2
        self.stg.FUNGRAD = False
        self.stg.HESSACT = False
        # Pre-pull Laplace
        self.stg.LAPLACE_PULL = False
        self.stg.MAP_PULL = None
        # Overwriting/reloading
        self.OVERWRITE = False
        self.RELOAD = False
        # Random seed
        self.stg.SEED = None
        # Batching
        self.BATCH_SIZE = None

    def _check_required_args(self):
        super(ConstructionScript, self)._check_required_args()
            
        # Check for required arguments
        if self.OVERWRITE and self.RELOAD:
            self.usage()
            self.tstamp_print("ERROR: options --overwrite and --reload are mutually esclusive")
            sys.exit(3)
        path = '/'.join( self.OUTPUT.split('/')[:-1] )
        if not os.path.exists(path):
            self.tstamp_print("ERROR: path '" + path + "' does not exist.")
            sys.exit(3)
        if not self.OVERWRITE and not self.RELOAD and os.path.exists(self.OUTPUT):
            sel = ''
            while sel not in ['o', 'r', 'q']:
                sel = input("The file %s already exists. " % self.OUTPUT + \
                            "Do you want to overwrite (o), reload (r) or quit (q)? [o/r/q] ")
            if sel == 'o':
                while sel not in ['y', 'n']:
                    sel = input("Please, confirm that you want overwrite. [y/n] ")
                if sel == 'n':
                    self.tstamp_print("Terminating.")
                    sys.exit(0)
            elif sel == 'r':
                self.RELOAD = True
            else:
                self.tstamp_print("Terminating.")
                sys.exit(0)
        if self.RELOAD:
            if self.stg.SEED is not None:
                self.tstamp_print(
                    "WARNING: a seed is defined in the reloaded options. " + \
                    "Reloading with a fixed seed does not correspond to a single run " + \
                    "with the same seed.")
        else:
            if None in [self.stg.QTYPE, self.stg.QNUM]:
                self.usage()
                self.tstamp_print("ERROR: Options --qtype and --qnum must be specified")
                sys.exit(3)
            if self.stg.QTYPE < 3:
                self.stg.QNUM = self.stg.QNUM[0]
            map_descr_list = [self.MONOTONE, self.SPAN, self.BTYPE, self.ORDER]
            is_not_subclass = ( type(self) == ConstructionScript )
            if is_not_subclass and \
               self.MAP_DESCR is None and \
               self.MAP_PKL is None and \
               None in map_descr_list:
                self.usage()
                self.tstamp_print("ERROR: Either options --mtype, --span, --btype, " + \
                      "--order are specified or option --map-descr is specified")
                sys.exit(3)
            elif is_not_subclass and \
                 ( self.MAP_DESCR is not None or \
                   self.MAP_PKL is not None ) and \
                 not all([s is None for s in map_descr_list]):
                self.usage()
                self.tstamp_print("ERROR: Either options --mtype, --span, --btype, " + \
                      "--order are specified or option --map-descr is specified")
                sys.exit(3)
            if self.stg.ADAPT not in AO.AVAIL_ADAPTIVITY:
                self.usage()
                self.tstamp_print("ERROR: adaptivity algorithm not recognized")
                sys.exit(3)
            if self.stg.ADAPT_FV_COEFF_TRUNC_TYPE not in AO.AVAIL_ADAPT_TRUNC:
                self.usage()
                self.tstamp_print("ERROR: coefficient truncation type not recognized")
                sys.exit(3)
            else:
                if self.stg.ADAPT_FV_COEFF_TRUNC_TYPE == 'manual':
                    self.stg.ADAPT_FV_COEFF_TRUNC_VAL = None
                elif self.stg.ADAPT_FV_COEFF_TRUNC_TYPE == 'percentage':
                    self.stg.ADAPT_FV_COEFF_TRUNC_VAL = float(self.stg.ADAPT_FV_COEFF_TRUNC_VAL)
                elif self.stg.ADAPT_FV_COEFF_TRUNC_TYPE == 'constant':
                    self.stg.ADAPT_FV_COEFF_TRUNC_VAL = int(self.stg.ADAPT_FV_COEFF_TRUNC_VAL)
            if self.stg.ADAPT_FV_AVAR_TRUNC_TYPE not in AO.AVAIL_ADAPT_TRUNC:
                self.usage()
                self.tstamp_print("ERROR: coefficient truncation type not recognized")
                sys.exit(3)
            else:
                if self.stg.ADAPT_FV_AVAR_TRUNC_TYPE == 'manual':
                    self.stg.ADAPT_FV_AVAR_TRUNC_VAL = None
                elif self.stg.ADAPT_FV_AVAR_TRUNC_TYPE == 'percentage':
                    self.stg.ADAPT_FV_AVAR_TRUNC_VAL = float(self.stg.ADAPT_FV_AVAR_TRUNC_VAL)
                elif self.stg.ADAPT_FV_AVAR_TRUNC_TYPE == 'constant':
                    self.stg.ADAPT_FV_AVAR_TRUNC_VAL = int(self.stg.ADAPT_FV_AVAR_TRUNC_VAL)
            if self.stg.ADAPT_FV_PRUNE_TRUNC_TYPE not in AO.AVAIL_ADAPT_TRUNC:
                self.usage()
                self.tstamp_print("ERROR: prune truncation type not recognized")
                sys.exit(3)
            else:
                if self.stg.ADAPT_FV_PRUNE_TRUNC_TYPE == 'manual':
                    self.stg.ADAPT_FV_PRUNE_TRUNC_VAL = None
                elif self.stg.ADAPT_FV_PRUNE_TRUNC_TYPE == 'percentage':
                    self.stg.ADAPT_FV_PRUNE_TRUNC_VAL = float(self.stg.ADAPT_FV_PRUNE_TRUNC_VAL)
                elif self.stg.ADAPT_FV_PRUNE_TRUNC_TYPE == 'constant':
                    self.stg.ADAPT_FV_PRUNE_TRUNC_VAL = int(self.stg.ADAPT_FV_PRUNE_TRUNC_VAL)

    def safe_store(self, tm):
        precond_map = [ ]
        if self.stg.LAPLACE_PULL:
            precond_map.append( self.stg.lapmap )
        if self.stg.MAP_PULL is not None:
            precond_map.append( self.stg.map_pull )

        if len(precond_map) == 0:
            self.stg.tmap = tm
        else:
            self.stg.precond_map = MAPS.ListCompositeTransportMap(
                map_list=precond_map )
            self.stg.tmap = MAPS.CompositeTransportMap(self.stg.precond_map, tm)

        self.stg.approx_base_distribution = DIST.PullBackParametricTransportMapDistribution(
            self.stg.tmap, self.stg.target_distribution)
        self.stg.approx_target_distribution = DIST.PushForwardParametricTransportMapDistribution(
            self.stg.tmap, self.stg.base_distribution)

        super().safe_store( self.stg, self.OUTPUT )
                    
    def load(self):
        # Setting the seed if any
        if self.stg.SEED is not None:
            npr.seed(self.stg.SEED)

        ##################### DATA LOADING #####################
        if self.RELOAD:
            with open(self.OUTPUT, 'rb') as istr:
                self.stg = dill.load(istr)

            # Set callback in builder
            self.stg.builder.callback = self.safe_store
            self.stg.builder.callback_kwargs = {}

        else:
            # Create an object to store the state of the builder
            self.stg.builder_state = TM.DataStorageObject()
            
            # Load target distribution
            with open(self.INPUT,'rb') as istr:
                self.stg.target_distribution = dill.load(istr)
            dim = self.stg.target_distribution.dim

            # Load base distribution
            if self.BASE_DIST_FNAME is None:
                self.stg.base_distribution = DIST.StandardNormalDistribution(dim)
            else:
                with open(self.BASE_DIST_FNAME,'rb') as istr:
                    self.stg.base_distribution = dill.load(istr)

            # Instantiate Transport Map
            if self.MAP_DESCR is not None:
                if self.stg.ADAPT == 'sequential':
                    self.usage()
                    self.tstamp_print("ERROR: option --adapt=sequential is not available with --map-descr (yet..)")
                    sys.exit(3)
                self.stg.tm = TMXML.load_xml(self.MAP_DESCR)
            elif self.MAP_PKL is not None:
                with open(self.MAP_PKL, 'rb') as istr:
                    self.stg.tm = dill.load( istr )
            elif self.MAP_FACTORY_PKL is not None:
                with open(self.MAP_FACTORY_PKL, 'rb') as istr:
                    self.stg.tm_factory = dill.load( istr )
            else:
                if self.MONOTONE == 'linspan':
                    if self.SPARSITY == 'tri':
                        map_constructor = \
                            MAPS.assemble_IsotropicLinearSpanTriangularTransportMap
                    elif self.SPARSITY == 'diag':
                        map_constructor = \
                            MAPS.assemble_IsotropicLinearSpanDiagonalTransportMap
                elif self.MONOTONE == 'intexp':
                    if self.SPARSITY == 'tri':
                        map_constructor = \
                            MAPS.assemble_IsotropicIntegratedExponentialTriangularTransportMap
                    elif self.SPARSITY == 'diag':
                        map_constructor = \
                            MAPS.assemble_IsotropicIntegratedExponentialDiagonalTransportMap
                elif self.MONOTONE == 'intsq':
                    if self.SPARSITY == 'tri':
                        map_constructor = \
                            MAPS.assemble_IsotropicIntegratedSquaredTriangularTransportMap
                    elif self.SPARSITY == 'diag':
                        map_constructor = \
                            MAPS.assemble_IsotropicIntegratedSquaredDiagonalTransportMap
                else:
                    raise ValueError("Monotone type not recognized (linspan|intexp|intsq)")
                if self.stg.ADAPT in ['none','fv']:
                    self.stg.tm = map_constructor(dim, self.ORDER, span=self.SPAN, btype=self.BTYPE)
                    logging.info("Number coefficients: %d" % self.stg.tm.n_coeffs)
                elif self.stg.ADAPT in ['sequential', 'tol-sequential']:
                    self.stg.tm_list = [
                        map_constructor(dim, o, span=self.SPAN, btype=self.BTYPE)
                        for o in range(1,self.ORDER+1) ]
                    n_coeffs = sum( tm.n_coeffs for tm in self.stg.tm_list )
                    logging.info("Number coefficients: %d" % n_coeffs )

            # Set up validator
            if self.stg.VALIDATOR == 'none':
                self.stg.validator = None
            else:
                if self.stg.VAL_COST_FUN == 'tot-time':
                    cost_fun = TM.total_time_cost_function
                if self.stg.VALIDATOR == 'saa':
                    self.stg.validator = DIAG.SampleAverageApproximationKLMinimizationValidator(
                        self.stg.VAL_EPS,
                        self.stg.VAL_SAA_EPS_ABS,
                        cost_fun,
                        self.stg.VAL_MAX_COST,
                        max_nsamps=self.stg.VAL_MAX_NSAMPS,
                        stop_on_fcast=self.stg.VAL_STOP_ON_FCAST,
                        upper_mult=self.stg.VAL_SAA_UPPER_MULT,
                        lower_n=self.stg.VAL_SAA_LOWER_N,
                        alpha=self.stg.VAL_SAA_ALPHA,
                        lmb_def=self.stg.VAL_SAA_LMB_DEF,
                        lmb_max=self.stg.VAL_SAA_LMB_MAX)
                elif self.stg.VALIDATOR == 'gradboot':
                    self.stg.validator = DIAG.GradientBootstrapKLMinimizationValidator(
                        self.stg.VAL_EPS,
                        delta=self.stg.VAL_GRADBOOT_DELTA,
                        cost_function=cost_fun,
                        max_cost=self.stg.VAL_MAX_COST,
                        max_nsamps=self.stg.VAL_MAX_NSAMPS,
                        stop_on_fcast=self.stg.VAL_STOP_ON_FCAST,
                        n_grad_samps=self.stg.VAL_GRADBOOT_N_GRAD,
                        n_bootstrap=self.stg.VAL_GRADBOOT_N_BOOT,
                        alpha=self.stg.VAL_GRADBOOT_ALPHA,
                        lmb_min=self.stg.VAL_GRADBOOT_LMB_MIN,
                        lmb_max=self.stg.VAL_GRADBOOT_LMB_MAX)

            # Set up solve parameters
            if self.stg.ADAPT in ['none', 'fv']:
                self.stg.solve_params = {
                    'qtype': self.stg.QTYPE,
                    'qparams': self.stg.QNUM,
                    'tol': self.stg.TOL,
                    'maxit': self.stg.MAXIT,
                    'regularization': None if self.stg.REG is None else self.stg.REG[0],
                    'ders': self.stg.DERS,
                    'fungrad': self.stg.FUNGRAD,
                    'hessact': self.stg.HESSACT,
                    'batch_size': self.BATCH_SIZE
                }
            elif self.stg.ADAPT in ['sequential', 'tol-sequential']:
                if self.stg.REG is not None and len(self.stg.REG) == 1:
                    self.stg.REG = self.stg.REG * self.ORDER
                self.stg.solve_params_list = []
                for i in range(len(self.stg.tm_list)):
                    self.stg.solve_params_list.append( {
                        'qtype': self.stg.QTYPE, 'qparams': self.stg.QNUM,
                        'tol': self.stg.TOL, 'maxit': self.stg.MAXIT,
                        'regularization': None if self.stg.REG is None else self.stg.REG[i],
                        'ders': self.stg.DERS, 'fungrad': self.stg.FUNGRAD, 'hessact': self.stg.HESSACT,
                        'batch_size': self.BATCH_SIZE
                    } )
                if self.stg.ADAPT == 'tol-sequential':
                    var_diag_params = {
                        'qtype': self.MONITOR_QTYPE,
                        'qparams': self.MONITOR_QNUM
                    }

            # Set up adaptivity algorithm
            callback_kwargs = {}  # Define callback (storage) arguments
            if self.stg.ADAPT == 'none':
                self.stg.builder = BUILD.KullbackLeiblerBuilder(
                    self.stg.validator,
                    callback=self.safe_store,
                    callback_kwargs=callback_kwargs,
                    verbosity=self.stg.ADAPT_VERB)
            else:
                regression_params = {
                    'regularization': self.stg.ADAPT_REGR_REG,
                    'tol': self.stg.ADAPT_REGR_TOL,
                    'maxit': self.stg.ADAPT_REGR_MAX_IT }
                if self.stg.ADAPT_REGR == 'none':
                    regressor = BUILD.L2RegressionBuilder(regression_params)
                elif self.stg.ADAPT_REGR == 'tol-sequential':
                    raise NotImplementedError(
                        "--adapt-regr=tol-sequential not supported by this script")

                if self.stg.ADAPT == 'sequential':
                    self.stg.builder = ALGADPT.SequentialKullbackLeiblerBuilder(
                        validator=self.stg.validator,
                        callback=self.safe_store,
                        callback_kwargs=callback_kwargs,
                        verbosity=self.stg.ADAPT_VERB)
                elif self.stg.ADAPT == 'tol-sequential':
                    self.stg.builder = ALGADPT.ToleranceSequentialKullbackLeiblerBuilder(
                        validator=self.stg.validator,
                        tol=self.stg.ADAPT_TOL,
                        callback=self.safe_store,
                        callback_kwargs=callback_kwargs,
                        verbosity=self.stg.ADAPT_VERB)
                elif self.stg.ADAPT == 'fv':
                    line_search_params = {'maxiter': self.stg.ADAPT_FV_LS_MAXIT,
                                          'delta': self.stg.ADAPT_FV_LS_DELTA}
                    prune_trunc = {'type': self.stg.ADAPT_FV_PRUNE_TRUNC_TYPE,
                                   'val': self.stg.ADAPT_FV_PRUNE_TRUNC_VAL}
                    avar_trunc = {'type': self.stg.ADAPT_FV_AVAR_TRUNC_TYPE,
                                  'val': self.stg.ADAPT_FV_AVAR_TRUNC_VAL}
                    coeff_trunc = {'type': self.stg.ADAPT_FV_COEFF_TRUNC_TYPE,
                                   'val': self.stg.ADAPT_FV_COEFF_TRUNC_VAL}
                    self.stg.builder = ALGADPT.FirstVariationKullbackLeiblerBuilder(
                        validator=self.stg.validator,
                        eps_bull=self.stg.ADAPT_TOL,
                        regression_builder=regressor,
                        line_search_params=line_search_params,
                        max_it=self.stg.ADAPT_FV_MAX_IT,
                        prune_trunc=prune_trunc,
                        avar_trunc=avar_trunc,
                        coeff_trunc=coeff_trunc,
                        interactive=self.stg.ADAPT_FV_INTERACTIVE,
                        callback=self.safe_store,
                        callback_kwargs=callback_kwargs,
                        verbosity=self.stg.ADAPT_VERB)

    def _precondition(self, *args, **kwargs):
        tar = self.stg.target_distribution

        # Map pullback
        self.stg.map_pull = None
        if self.stg.MAP_PULL is not None:
            with open(self.stg.MAP_PULL, 'rb') as istr:
                self.stg.map_pull = dill.load(istr)
            if not issubclass(type(self.stg.map_pull), MAPS.Map):
                self.stg.map_pull = self.stg.map_pull.tmap
            tar = DIST.PullBackTransportMapDistribution(
                self.stg.map_pull, tar )

        # Laplace pullback
        self.stg.lapmap = None
        if self.stg.LAPLACE_PULL:
            laplace_approx = TM.laplace_approximation( tar )
            self.stg.lapmap = MAPS.LinearTransportMap.build_from_Gaussian( laplace_approx )
            tar = DIST.PullBackTransportMapDistribution(
                self.stg.lapmap, tar )

        return tar

    def _solve(self, mpi_pool=None):
        if not self.RELOAD:
            # Set up builder_solve_kwargs
            if self.stg.ADAPT in ['none', 'fv']:
                self.stg.builder_solve_kwargs = {
                    'transport_map': self.stg.tm,
                    'base_distribution': self.stg.base_distribution,
                    'target_distribution': self.stg.preconditioned_target_distribution,
                    'solve_params': self.stg.solve_params
                }
            elif self.stg.ADAPT in ['sequential', 'tol-sequential']:
                self.stg.builder_solve_kwargs = {
                    'transport_map': self.stg.tm_list,
                    'base_distribution': self.stg.base_distribution,
                    'target_distribution': self.stg.preconditioned_target_distribution,
                    'solve_params': self.stg.solve_params_list
                }
                if self.stg.ADAPT == 'tol-sequential':
                    self.stg.builder_solve_kwargs['var_diag_params'] = var_diag_params
            
        return self.stg.builder.solve(
            state=self.stg.builder_state,
            mpi_pool=mpi_pool,
            **self.stg.builder_solve_kwargs
        )
                
    def run(self, *args, **kwargs):

        if not self.RELOAD:
            self.stg.preconditioned_target_distribution = \
                self._precondition()
                
        # Start mpi pool
        mpi_pool = None
        if self.NPROCS > 1:
            mpi_pool = TM.get_mpi_pool()
            mpi_pool.start(self.NPROCS)

        try:

            # Solve
            (tm, log) = self._solve(mpi_pool=mpi_pool)

            # Store
            self.safe_store(tm)
            
        finally:
            if mpi_pool is not None:
                mpi_pool.stop()
            if self.INTERACTIVE:
                from IPython import embed
                embed()
